<footer class="bg-gradient-to-r from-gray-800 via-gray-900 to-black text-white shadow-lg sticky bottom-0 left-0 w-full py-4 border-t border-gray-700">
    <div class="container mx-auto px-4 md:px-6">
        <div class="flex justify-around items-center text-2xl">
            <!-- 🏠 Home -->
            <a href="../index.php" class="flex flex-col items-center hover:text-blue-400 transition duration-200 transform hover:scale-105">
                ⌂
                <span class="text-xs mt-1">Home</span>
            </a>

            <!-- 🎥 Videos -->
            <a href="https://www.youtube.com/@AnOutlier1217" class="flex flex-col items-center hover:text-blue-400 transition duration-200 transform hover:scale-105">
                🎥
                <span class="text-xs mt-1">Videos</span>
            </a>

            <!-- 🤝 My Tie-Ups -->
            <a href="../users/my_tieups.php" class="flex flex-col items-center hover:text-blue-400 transition duration-200 transform hover:scale-105">
                🤝
                <span class="text-xs mt-1">My Tie-Ups</span>
            </a>

            <!-- 🔔 Notifications (Tie-Up Requests) -->
            <a href="../users/tie_up_requests.php" class="relative flex flex-col items-center hover:text-blue-400 transition duration-200 transform hover:scale-105">
                🔔
                <span class="text-xs mt-1">Alerts</span>
                <span id="notification-count" class="absolute -top-2 -right-3 bg-red-600 text-white text-xs font-semibold px-2 py-1 rounded-full hidden">0</span>
            </a>

            <!-- 📩 Suggestion Box -->
            <a href="../users/suggestion_box.php" class="flex flex-col items-center hover:text-blue-400 transition duration-200 transform hover:scale-105">
                📩
                <span class="text-xs mt-1">Suggest</span>
            </a>
        </div>
    </div>
</footer>

<script>
// Update Notification Count
async function updateNotificationCount() {
    try {
        const response = await fetch("../users/fetch_notifications_count.php");
        const data = await response.json();
        const notificationBadge = document.getElementById("notification-count");
        notificationBadge.textContent = data.count;
        notificationBadge.classList.toggle("hidden", data.count <= 0);
    } catch (error) {
        console.error("Error fetching notifications:", error);
    }
}

// Initial call and periodic refresh
updateNotificationCount();
setInterval(updateNotificationCount, 10000);
</script>

<style>
    body {
        padding-bottom: 80px; /* Matches footer height for content visibility */
    }

    footer {
        z-index: 10; /* Ensures footer stays above other content */
    }

    /* Subtle hover animation for icons */
    footer {
    background: linear-gradient(to right, #f1f5f9, #e2e8f0);
    color: #4b5563; /* text-gray-600 */
    border-top: 1px solid #e5e7eb; /* border-gray-200 */
}
footer a:hover {
    color: #3b82f6; /* hover:text-blue-500 */
}

    /* Responsive adjustments */
    @media (max-width: 640px) {
        footer .text-2xl {
            font-size: 1.25rem; /* Smaller icons on mobile */
        }
        footer .text-xs {
            font-size: 0.65rem; /* Smaller text on mobile */
        }
    }
</style>