<?php
include 'db.php';

// Check if user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Use prepared statement to fetch user data
    $query = "SELECT name, profile_picture FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user_id); // 'i' for integer
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Check if user exists
    if ($user) {
        // Set default profile picture if empty
        $profile_picture = !empty($user['profile_picture']) ? htmlspecialchars($user['profile_picture']) : 'default.png';
        $user_name = htmlspecialchars($user['name']);
    } else {
        // Handle case where user is not found (e.g., invalid session)
        $profile_picture = 'default.png';
        $user_name = 'Guest';
        error_log("No user found for user_id: $user_id"); // Log for debugging
    }
    $stmt->close();

    // Fetch unread messages count
    $query_messages = "SELECT COUNT(*) AS unread_count FROM messages WHERE receiver_id = ? AND is_read = 0";
    $stmt_messages = $conn->prepare($query_messages);
    $stmt_messages->bind_param('i', $user_id);
    $stmt_messages->execute();
    $result_messages = $stmt_messages->get_result();
    $unread_count = $result_messages->fetch_assoc()['unread_count'];
    $stmt_messages->close();

    // Fetch latest unread messages
    $query_latest_messages = "SELECT messages.id, messages.message, messages.sender_id, users.name 
                             FROM messages 
                             JOIN users ON messages.sender_id = users.id 
                             WHERE messages.receiver_id = ? 
                             AND messages.is_read = 0 
                             ORDER BY messages.created_at DESC 
                             LIMIT 5";
    $stmt_latest_messages = $conn->prepare($query_latest_messages);
    $stmt_latest_messages->bind_param('i', $user_id);
    $stmt_latest_messages->execute();
    $result_latest_messages = $stmt_latest_messages->get_result();
} else {
    // If user is not logged in, set defaults
    $profile_picture = 'default.png';
    $user_name = 'Guest';
    $unread_count = 0;
    $result_latest_messages = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Joaballoc - Job Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-gray-50">

<!-- Navigation Bar -->
<nav class="bg-white p-4 text-gray-800 shadow-md sticky top-0 z-50">
    <div class="container mx-auto flex justify-between items-center">
        <!-- Profile Icon OR Login/Signup -->
        <div class="flex items-center space-x-4">
            <?php if (isset($_SESSION['user_id'])): ?>
                <img src="../assets/images/<?php echo htmlspecialchars($profile_picture); ?>" 
                     alt="Profile" id="profile-icon"
                     class="w-11 h-11 rounded-full border-2 border-gray-300 shadow-md cursor-pointer hover:scale-105 transition duration-200">
            <?php else: ?>
                <a href="../auth/login.php" class="bg-indigo-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-indigo-700 transition">Login</a>
                <a href="../auth/signup.php" class="bg-yellow-400 text-gray-800 px-4 py-2 rounded-lg font-semibold hover:bg-yellow-500 transition">Sign Up</a>
            <?php endif; ?>
        </div>

        <!-- Search Bar -->
        <?php if (isset($_SESSION['user_id'])): ?>
        <div class="relative w-48 md:w-64 lg:w-80">
            <input type="text" id="search-input" 
                   class="w-full p-2 pl-10 rounded-lg border border-gray-300 text-gray-800 bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition shadow-sm" 
                   placeholder="Search...">
            <span class="absolute left-3 top-2.5 text-gray-500">🔍</span>
            <div id="search-results" 
                 class="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg hidden max-h-64 overflow-y-auto z-10"></div>
        </div>
        <?php endif; ?>

        <!-- Right Side Icons -->
        <div class="flex items-center space-x-8">
            <?php if (isset($_SESSION['user_id'])): ?>
                <!-- Custom Plus Icon -->
                <a href="../users/post_job.php" 
                   class="relative flex items-center justify-center w-9 h-9 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition duration-200 shadow-md">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                    </svg>
                </a>

                <!-- Messages & Notifications -->
                <div class="relative">
                    <button id="notification-btn" class="text-2xl text-gray-600 hover:text-indigo-600 transition relative">
                        🔔
                        <?php if ($unread_count > 0): ?>
                            <span class="absolute -top-2 -right-2 bg-red-600 text-white text-xs font-semibold px-2 py-1 rounded-full shadow-sm">
                                <?php echo $unread_count; ?>
                            </span>
                        <?php endif; ?>
                    </button>
                    <div id="notification-dropdown" 
                         class="hidden absolute right-0 mt-2 bg-white text-gray-800 shadow-xl rounded-lg w-72 z-20">
                        <h3 class="text-lg font-semibold px-4 py-2 bg-gray-100 text-gray-700">Messages</h3>
                        <div id="notifications-list" class="p-3 space-y-3 max-h-64 overflow-y-auto">
                            <?php if ($result_latest_messages && mysqli_num_rows($result_latest_messages) > 0): ?>
                                <?php while ($msg = mysqli_fetch_assoc($result_latest_messages)): ?>
                                    <a href="../users/chat.php?user_id=<?php echo $msg['sender_id']; ?>" 
                                       class="block px-4 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition">
                                        <strong class="text-indigo-600"><?php echo htmlspecialchars($msg['name']); ?>:</strong> 
                                        <?php echo htmlspecialchars(substr($msg['message'], 0, 50)) . '...'; ?>
                                    </a>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-gray-500 text-center py-4">No new messages</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Profile Sidebar -->
<?php if (isset($_SESSION['user_id'])): ?>
<div id="profile-sidebar" 
     class="fixed top-0 left-0 w-72 h-full bg-white shadow-2xl transform -translate-x-full transition-transform duration-300 z-50">
    <button id="close-profile-sidebar" class="absolute top-4 right-4 text-2xl text-gray-600 hover:text-gray-800">✖</button>

    <div class="p-6 text-center">
        <img src="../assets/images/<?php echo htmlspecialchars($profile_picture); ?>" 
             alt="Profile" 
             class="w-24 h-24 rounded-full mx-auto border-2 border-gray-300 shadow-lg object-cover">
        <h2 class="text-xl font-semibold mt-4 text-gray-800"><?php echo htmlspecialchars($user_name); ?></h2>

        <div class="mt-6 space-y-3">
            <a href="../users/dashboard.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">🏠 Dashboard</a>
            <a href="../index.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">📂 Home</a>
            <a href="../auth/logout.php" class="block px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition">🚪 Logout</a>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Toggle Profile Sidebar
document.getElementById("profile-icon")?.addEventListener("click", () => {
    document.getElementById("profile-sidebar").classList.remove("-translate-x-full");
});

// Close Profile Sidebar
document.getElementById("close-profile-sidebar")?.addEventListener("click", () => {
    document.getElementById("profile-sidebar").classList.add("-translate-x-full");
});

// Toggle Notification Dropdown
document.getElementById("notification-btn")?.addEventListener("click", (e) => {
    e.stopPropagation();
    document.getElementById("notification-dropdown").classList.toggle("hidden");
});

// Close Notification Dropdown on Outside Click
document.addEventListener("click", (e) => {
    const dropdown = document.getElementById("notification-dropdown");
    if (!e.target.closest("#notification-btn") && !e.target.closest("#notification-dropdown")) {
        dropdown.classList.add("hidden");
    }
});

// Search Functionality
document.getElementById("search-input")?.addEventListener("keyup", async () => {
    const query = document.getElementById("search-input").value.trim();
    const results = document.getElementById("search-results");
    results.classList.toggle("hidden", !query);
    if (query) {
        const response = await fetch(`../search.php?query=${encodeURIComponent(query)}`);
        results.innerHTML = await response.text();
    }
});
</script>

</body>
</html>