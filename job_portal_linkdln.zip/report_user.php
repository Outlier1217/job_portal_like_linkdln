<?php
session_start();
include 'includes/header.php';
include 'includes/db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['user_id'])) {
    die("Unauthorized access.");
}

$reported_user_id = $_GET['user_id'];

// Fetch user details
$query_user = "SELECT name FROM users WHERE id = '$reported_user_id'";
$result_user = mysqli_query($conn, $query_user);
$reported_user = mysqli_fetch_assoc($result_user);
?>

<div class="min-h-screen bg-gray-100 flex justify-center items-center">
    <div class="max-w-md w-full bg-white shadow-lg rounded-lg p-8">
        <h2 class="text-2xl font-bold mb-4 text-red-500">Report User</h2>
        <p class="mb-4">You are reporting <strong><?php echo htmlspecialchars($reported_user['name']); ?></strong></p>

        <form id="report-form" action="submit_report.php" method="POST">
            <input type="hidden" name="reported_user_id" value="<?php echo $reported_user_id; ?>">

            <label class="block text-gray-700">Reason for Reporting:</label>
            <textarea name="report_reason" class="w-full p-2 border rounded mt-2" rows="4" required></textarea>

            <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded w-full mt-4 hover:bg-red-600">Submit Report</button>
        </form>
    </div>
</div>

<!-- Success Popup -->
<div id="success-popup" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg">
        <h3 class="text-xl font-semibold">✅ Report Submitted Successfully!</h3>
        <p class="mt-2 text-gray-700">Your report has been received and will be reviewed.</p>
        <button onclick="closePopup()" class="mt-4 bg-blue-500 text-white px-4 py-2 rounded">OK</button>
    </div>
</div>

<script>
document.getElementById("report-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent normal form submission

    let formData = new FormData(this);

    fetch("submit_report.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            document.getElementById("success-popup").classList.remove("hidden");
        } else {
            alert("Error submitting report.");
        }
    })
    .catch(error => console.error("Error:", error));
});

// Function to close the popup and redirect
function closePopup() {
    document.getElementById("success-popup").classList.add("hidden");
    window.location.href = "index.php"; // Redirect to home after closing popup
}
</script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>
<?php include 'includes/footer.php'; ?>
