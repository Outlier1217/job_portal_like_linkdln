<?php
session_start();
include 'includes/header.php';
include 'includes/db.php';

// Check if the user is logged in
$is_logged_in = isset($_SESSION['user_id']);

// Fetch all job posts
$query = "SELECT jobs.id, jobs.job_title, jobs.job_description, jobs.created_at, 
                 users.name, users.profile_picture, users.id AS user_id,
                 (SELECT e.current_post_role 
                  FROM education_experience e 
                  WHERE e.user_id = users.id 
                  AND e.current_post_role IS NOT NULL 
                  ORDER BY e.start_date DESC 
                  LIMIT 1) AS current_post_role 
          FROM jobs 
          JOIN users ON jobs.user_id = users.id 
          ORDER BY jobs.created_at DESC";

$result = mysqli_query($conn, $query);
?>

<!-- Main Content -->
<div class="min-h-screen bg-gray-50 px-4 py-8 md:px-6 lg:px-8">
    <!-- Job Posts Section -->
    <div class="max-w-4xl mx-auto mt-8">
        <h2 class="text-3xl font-bold text-gray-800 mb-8 text-center">Latest Job Posts</h2>

        <div id="job-posts" class="space-y-6">
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="bg-white shadow-md rounded-xl p-6 relative transition-all duration-200 hover:shadow-lg hover:-translate-y-1 border border-gray-100">
                    <!-- Three-Dot Menu -->
                    <div class="absolute top-4 right-4">
                        <button class="menu-btn text-gray-500 hover:text-gray-800 text-xl font-bold" 
                                data-menu-id="menu-<?php echo $row['id']; ?>">⋮</button>
                        <div id="menu-<?php echo $row['id']; ?>" 
                             class="hidden absolute right-0 mt-2 bg-white shadow-md rounded-lg w-40 z-10 border border-gray-200">
                            <a href="report_user.php?user_id=<?php echo $row['user_id']; ?>" 
                               class="block px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg text-sm font-medium">⚠️ Report</a>
                        </div>
                    </div>

                    <!-- User Info -->
                    <div class="flex items-center mb-4">
                        <img src="assets/images/<?php echo $row['profile_picture']; ?>" 
                             alt="Profile" 
                             class="w-12 h-12 rounded-full border-2 border-gray-200 object-cover shadow-sm">
                        <div class="ml-4">
                            <h3 class="text-lg font-semibold">
                                <a href="users/user_profile.php?user_id=<?php echo $row['user_id']; ?>" 
                                   class="text-indigo-600 hover:underline">
                                    <?php echo htmlspecialchars($row['name']); ?>
                                </a>
                            </h3>
                            <p class="text-gray-600 text-sm">
                                <?php 
                                echo !empty($row['current_post_role']) 
                                    ? htmlspecialchars($row['current_post_role']) 
                                    : "<span class='text-gray-400 italic'>No Role Specified</span>";
                                ?>
                            </p>
                        </div>
                    </div>

                    <!-- Job Info -->
                    <h2 class="text-xl font-bold text-gray-800"><?php echo htmlspecialchars($row['job_title']); ?></h2>
                    <p class="text-gray-600 mt-2 leading-relaxed"><?php echo htmlspecialchars($row['job_description']); ?></p>

                    <!-- Comment Section -->
                    <div class="mt-6">
                        <span class="toggle-comments text-gray-500 hover:text-indigo-600 cursor-pointer transition text-sm font-medium" 
                              data-post-id="<?php echo $row['id']; ?>">
                            💬 Show Comments
                        </span>

                        <div class="comments-section hidden mt-4" id="comments-<?php echo $row['id']; ?>">
                            <div class="comment-list space-y-3 border-t border-gray-200 pt-3"></div>
                            
                            <!-- Comment Input -->
                            <div class="flex mt-4">
                                <input type="text" 
                                       class="comment-input w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 bg-gray-50 text-gray-800" 
                                       data-post-id="<?php echo $row['id']; ?>" 
                                       placeholder="Write a comment...">
                                <span class="submit-comment ml-3 cursor-pointer text-indigo-500 text-2xl hover:text-indigo-700 transition" 
                                      data-post-id="<?php echo $row['id']; ?>">📩</span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<script>
// Toggle Three-Dot Menu
document.querySelectorAll(".menu-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const menuId = btn.dataset.menuId;
        const menu = document.getElementById(menuId);
        document.querySelectorAll("[id^='menu-']").forEach(m => m !== menu && m.classList.add("hidden"));
        menu.classList.toggle("hidden");
    });
});

document.addEventListener("click", (e) => {
    if (!e.target.closest(".menu-btn") && !e.target.closest("[id^='menu-']")) {
        document.querySelectorAll("[id^='menu-']").forEach(menu => menu.classList.add("hidden"));
    }
});

// Toggle Comments
document.querySelectorAll(".toggle-comments").forEach(toggle => {
    toggle.addEventListener("click", () => {
        const postId = toggle.dataset.postId;
        const commentsSection = document.getElementById(`comments-${postId}`);
        const isHidden = commentsSection.classList.toggle("hidden");
        toggle.textContent = isHidden ? "💬 Show Comments" : "👀 Hide Comments";
        if (!isHidden) loadComments(postId);
    });
});

// Submit Comment
document.addEventListener("keypress", async (e) => {
    if (e.key === "Enter" && e.target.classList.contains("comment-input")) {
        const postId = e.target.dataset.postId;
        const commentText = e.target.value.trim();
        if (!commentText) return alert("Comment cannot be empty!");

        try {
            const response = await fetch("users/comment_post.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ post_id: postId, comment: commentText })
            });
            const data = await response.json();
            if (data.status === "success") {
                e.target.value = "";
                loadComments(postId);
            } else {
                alert(`Error: ${data.message}`);
            }
        } catch (error) {
            console.error("Error:", error);
        }
    }
});

// Load Comments
async function loadComments(postId) {
    try {
        const response = await fetch(`users/fetch_comments.php?post_id=${postId}`);
        const comments = await response.json();
        const container = document.querySelector(`#comments-${postId} .comment-list`);
        container.innerHTML = comments.length 
            ? comments.map(c => `<p class="text-gray-700 text-sm"><strong class="text-gray-800">${c.name}:</strong> ${c.comment}</p>`).join("")
            : "<p class='text-gray-400 italic text-sm'>No comments yet.</p>";
    } catch (error) {
        console.error("Error:", error);
    }
}
</script>

<?php include 'includes/footer.php'; ?>