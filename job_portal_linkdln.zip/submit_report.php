<?php
session_start();
include 'includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $reported_user_id = $_POST['reported_user_id'];
    $report_reason = mysqli_real_escape_string($conn, $_POST['report_reason']);
    $reporter_id = $_SESSION['user_id'];

    $query = "INSERT INTO user_reports (reporter_id, reported_user_id, report_reason, created_at) 
              VALUES ('$reporter_id', '$reported_user_id', '$report_reason', NOW())";

    if (mysqli_query($conn, $query)) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error"]);
    }
    exit;
}
?>
