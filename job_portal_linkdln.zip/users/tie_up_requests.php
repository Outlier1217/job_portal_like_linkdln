<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

include '../includes/header.php';
include '../includes/db.php';

$user_id = $_SESSION['user_id'];

// Fetch all pending tie-up requests
$query_requests = "SELECT tie_up_requests.id AS request_id, users.id AS sender_id, users.name, users.profile_picture 
                   FROM tie_up_requests 
                   JOIN users ON tie_up_requests.sender_id = users.id 
                   WHERE tie_up_requests.receiver_id = '$user_id' AND tie_up_requests.status = 'pending'";
$result_requests = mysqli_query($conn, $query_requests);

// Fetch all accepted tie-ups
$query_accepted = "SELECT users.id, users.name, users.profile_picture, users.is_online,
                          (SELECT COUNT(*) FROM messages WHERE sender_id = users.id AND receiver_id = '$user_id' AND is_read = 0) AS unread_messages
                   FROM tie_up_requests 
                   JOIN users ON (tie_up_requests.sender_id = users.id OR tie_up_requests.receiver_id = users.id) 
                   WHERE (tie_up_requests.sender_id = '$user_id' OR tie_up_requests.receiver_id = '$user_id') 
                   AND tie_up_requests.status = 'accepted' 
                   AND users.id != '$user_id'";
$result_accepted = mysqli_query($conn, $query_accepted);
?>

<div class="min-h-screen bg-gray-100 py-10 px-4 md:px-10">
    <div class="max-w-5xl mx-auto bg-white shadow-lg rounded-lg p-8">

        <h2 class="text-2xl font-bold text-center mb-6">📌 Tie-Up Requests & Connected Users</h2>

        <!-- Pending Tie-Up Requests Section -->
        <div class="mt-10">
            <h3 class="text-xl font-semibold mb-4">⏳ Pending Tie-Up Requests</h3>

            <?php if (mysqli_num_rows($result_requests) > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php while ($request = mysqli_fetch_assoc($result_requests)): ?>
                        <div class="bg-gray-50 p-6 rounded-lg shadow">
                            <div class="flex items-center">
                                <img src="../assets/images/<?php echo htmlspecialchars($request['profile_picture']); ?>" 
                                     alt="Profile Picture" class="w-12 h-12 rounded-full border">
                                <div class="ml-4">
                                    <h4 class="text-lg font-semibold"><?php echo htmlspecialchars($request['name']); ?></h4>
                                </div>
                            </div>

                            <div class="mt-4 flex space-x-4">
                                <form action="accept_tie_up.php" method="POST">
                                    <input type="hidden" name="request_id" value="<?php echo $request['request_id']; ?>">
                                    <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                                        ✅ Accept
                                    </button>
                                </form>
                                <form action="reject_tie_up.php" method="POST">
                                    <input type="hidden" name="request_id" value="<?php echo $request['request_id']; ?>">
                                    <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">
                                        ❌ Reject
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="text-gray-500">No pending tie-up requests.</p>
            <?php endif; ?>
        </div>

        <!-- Accepted Tie-Ups (Connected Users) Section -->
        <div class="mt-10">
            <h3 class="text-xl font-semibold mb-4">✅ Connected Users</h3>

            <?php if (mysqli_num_rows($result_accepted) > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php while ($user = mysqli_fetch_assoc($result_accepted)): ?>
                        <div class="bg-gray-50 p-6 rounded-lg shadow">
                            <div class="flex items-center">
                                <img src="../assets/images/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                     alt="Profile Picture" class="w-12 h-12 rounded-full border">
                                <div class="ml-4">
                                    <h4 class="text-lg font-semibold">
                                        <a href="user_profile.php?user_id=<?php echo $user['id']; ?>" class="text-blue-500 hover:underline">
                                            <?php echo htmlspecialchars($user['name']); ?>
                                        </a>
                                    </h4>
                                    <span class="<?php echo $user['is_online'] ? 'text-green-500' : 'text-red-500'; ?>">
                                        <?php echo $user['is_online'] ? '🟢 Online' : '🔴 Offline'; ?>
                                    </span>
                                    <?php if ($user['unread_messages'] > 0): ?>
                                        <span class="ml-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs">
                                            <?php echo $user['unread_messages']; ?> New Message(s)
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="mt-4">
                                <a href="chat.php?user_id=<?php echo $user['id']; ?>" 
                                   class="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                                    💬 Message
                                </a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="text-gray-500">No connected users yet.</p>
            <?php endif; ?>
        </div>

    </div>
</div>

<?php include '../includes/footer.php'; ?>
