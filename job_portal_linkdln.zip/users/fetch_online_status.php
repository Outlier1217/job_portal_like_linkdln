<?php
include '../includes/db.php';

if (isset($_GET['user_id'])) {
    $user_id = mysqli_real_escape_string($conn, $_GET['user_id']);
    $query = "SELECT is_online FROM users WHERE id = '$user_id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    echo ($row['is_online'] == 1) ? '🟢 Online' : '🔴 Offline';
}
?>
