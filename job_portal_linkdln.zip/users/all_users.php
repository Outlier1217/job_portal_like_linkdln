<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

include '../includes/header.php';
include '../includes/db.php';

// Fetch all users except the logged-in user
$user_id = $_SESSION['user_id'];
$query = "SELECT id, name, email, profile_picture, qualifications, employment_status FROM users WHERE id != '$user_id'";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Database Query Failed: " . mysqli_error($conn));
}
?>

<div class="min-h-screen bg-gray-100 flex justify-center items-center">
    <div class="max-w-4xl w-full bg-white shadow-lg rounded-lg p-8">
        <h2 class="text-2xl font-bold mb-4 text-center">All Users</h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php while ($user = mysqli_fetch_assoc($result)): ?>
                    <?php
                    // Check if a tie-up request has already been sent
                    $receiver_id = $user['id'];
                    $check_query = "SELECT * FROM tie_up_requests WHERE sender_id='$user_id' AND receiver_id='$receiver_id'";
                    $check_result = mysqli_query($conn, $check_query);
                    $already_sent = mysqli_num_rows($check_result) > 0;
                    ?>

                    <div class="bg-gray-50 p-6 rounded-lg shadow">
                        <div class="flex items-center">
                            <img src="../assets/images/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                 alt="Profile Picture" class="w-16 h-16 rounded-full border">
                            <div class="ml-4">
                            <h4 class="text-lg font-semibold">
    <a href="user_profile.php?user_id=<?php echo $user['id']; ?>" class="text-blue-500 hover:underline">
        <?php echo htmlspecialchars($user['name']); ?>
    </a>
</h4>

                                <p class="text-gray-600 text-sm"><?php echo $user['qualifications'] ? htmlspecialchars($user['qualifications']) : "Not added"; ?></p>
                                <p class="text-sm">
                                    <strong>Employment:</strong> 
                                    <span class="px-3 py-1 rounded-full text-white 
                                        <?php echo $user['employment_status'] == 'Employed' ? 'bg-green-500' : 
                                               ($user['employment_status'] == 'Self-Employed' ? 'bg-yellow-500' : 'bg-blue-500'); ?>">
                                        <?php echo $user['employment_status'] ? htmlspecialchars($user['employment_status']) : "Not specified"; ?>
                                    </span>
                                </p>
                            </div>
                        </div>

                        <!-- Send Tie-Up Request Button -->
                        <div class="mt-4">
                            <?php if ($already_sent): ?>
                                <button class="w-full bg-gray-400 text-white px-4 py-2 rounded cursor-not-allowed"
                                        onclick="alert('Request already sent!');">
                                    Request Sent
                                </button>
                            <?php else: ?>
                                <form action="send_tie_up.php" method="POST">
                                    <input type="hidden" name="receiver_id" value="<?php echo $receiver_id; ?>">
                                    <button type="submit" class="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                                        Send Tie-Up Request
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-500 text-center">No users found.</p>
        <?php endif; ?>
    </div>
</div>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>

<?php include '../includes/footer.php'; ?>
