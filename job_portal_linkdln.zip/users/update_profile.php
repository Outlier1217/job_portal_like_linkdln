<?php
session_start();
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $qualifications = mysqli_real_escape_string($conn, $_POST['qualifications']);
    $job_experience = mysqli_real_escape_string($conn, $_POST['job_experience']);
    $employment_status = mysqli_real_escape_string($conn, $_POST['employment_status']);
    $current_work_status = mysqli_real_escape_string($conn, $_POST['current_work_status']);
    $current_organization = mysqli_real_escape_string($conn, $_POST['current_organization']);

    // Handle profile picture upload
    if (!empty($_FILES["profile_picture"]["name"])) {
        $target_dir = "../assets/images/";
        $imageFileType = strtolower(pathinfo($_FILES["profile_picture"]["name"], PATHINFO_EXTENSION));
        $profile_picture = uniqid() . "." . $imageFileType;
        $target_file = $target_dir . $profile_picture;

        // Validate file size and type
        if ($_FILES["profile_picture"]["size"] > 2000000 || !in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
            $_SESSION['error'] = "Invalid file format or size!";
            header("Location: edit_profile.php");
            exit();
        }

        // Move uploaded file
        if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
            // Update profile picture in database
            $query = "UPDATE users SET profile_picture='$profile_picture' WHERE id='$user_id'";
            mysqli_query($conn, $query);
        }
    }

    // Update user details
    $query = "UPDATE users SET 
                name='$name', 
                email='$email', 
                qualifications='$qualifications',
                job_experience='$job_experience',
                employment_status='$employment_status',
                current_work_status='$current_work_status',
                current_organization='$current_organization'
              WHERE id='$user_id'";

    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Profile updated successfully!";
        header("Location: dashboard.php");
    } else {
        $_SESSION['error'] = "Error updating profile.";
        header("Location: edit_profile.php");
    }
}
?>
