<?php
session_start();
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    
    // Escape special characters to prevent SQL errors & injection
    $job_title = mysqli_real_escape_string($conn, $_POST['job_title']);
    $job_description = mysqli_real_escape_string($conn, $_POST['job_description']);

    // Insert the job post into the database
    $sql = "INSERT INTO jobs (user_id, job_title, job_description) VALUES ('$user_id', '$job_title', '$job_description')";

    if (mysqli_query($conn, $sql)) {
        header("Location: dashboard.php?success=1");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
