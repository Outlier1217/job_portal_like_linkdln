<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/header.php';
include '../includes/db.php';

$user_id = $_SESSION['user_id'];

// Fetch unique chat conversations (one per user)
$query_chats = "SELECT DISTINCT users.id AS chat_user_id, users.name, users.profile_picture
                FROM messages
                JOIN users ON (messages.sender_id = users.id OR messages.receiver_id = users.id)
                WHERE (messages.sender_id = '$user_id' OR messages.receiver_id = '$user_id')
                AND users.id != '$user_id'
                ORDER BY messages.created_at DESC";
$result_chats = mysqli_query($conn, $query_chats);
?>

<div class="min-h-screen bg-gray-100 py-10 px-4 md:px-10">
    <div class="max-w-5xl mx-auto bg-white shadow-lg rounded-lg p-8">
        
        <!-- 📩 Chat Conversations -->
        <h3 class="text-xl font-semibold mb-4">💬 Chat History</h3>
        
        <?php if (mysqli_num_rows($result_chats) > 0): ?>
            <div class="bg-gray-50 p-6 rounded-lg shadow">
                <ul class="divide-y divide-gray-300">
                    <?php while ($chat = mysqli_fetch_assoc($result_chats)): ?>
                        <li class="py-4 flex items-center">
                            <img src="../assets/images/<?php echo htmlspecialchars($chat['profile_picture']); ?>" 
                                 alt="Profile Picture" class="w-10 h-10 rounded-full border">
                            <div class="ml-4">
                                <h4 class="text-lg font-semibold">
                                    <a href="chat.php?user_id=<?php echo $chat['chat_user_id']; ?>" 
                                       class="text-blue-500 hover:underline">
                                        <?php echo htmlspecialchars($chat['name']); ?>
                                    </a>
                                </h4>
                            </div>
                            <div class="ml-auto">
                                <a href="chat.php?user_id=<?php echo $chat['chat_user_id']; ?>" 
                                   class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                                    💬 Continue Chat
                                </a>
                            </div>
                        </li>
                    <?php endwhile; ?>
                </ul>
            </div>
        <?php else: ?>
            <p class="text-gray-500">No chat history available.</p>
        <?php endif; ?>
    </div>
</div>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>

<?php include '../includes/footer.php'; ?>
