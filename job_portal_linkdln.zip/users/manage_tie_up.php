<?php
session_start();
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tie_up_id = $_POST['tie_up_id'];
    $action = $_POST['action']; // 'accepted' or 'rejected'

    $sql = "UPDATE tie_ups SET status = '$action' WHERE id = '$tie_up_id'";
    if (mysqli_query($conn, $sql)) {
        echo "Tie-Up Request $action!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
