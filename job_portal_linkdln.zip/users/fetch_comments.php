<?php
include '../includes/db.php';

$post_id = $_GET['post_id'];
$query = "SELECT comments.comment, comments.created_at, users.name 
          FROM comments 
          JOIN users ON comments.user_id = users.id 
          WHERE comments.post_id = '$post_id' 
          ORDER BY comments.created_at DESC";
$result = mysqli_query($conn, $query);

$comments = [];
while ($row = mysqli_fetch_assoc($result)) {
    $comments[] = $row;
}

echo json_encode($comments);
?>
