<?php
session_start();
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $suggestion = $_POST['suggestion'];

    $query = "INSERT INTO suggestions (email, suggestion) VALUES ('$email', '$suggestion')";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['suggestion_success'] = true; // Set session to show success popup
        header("Location: suggestion_box.php"); // Redirect back
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
