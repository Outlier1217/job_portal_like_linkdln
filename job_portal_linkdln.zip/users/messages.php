<?php
session_start();
include '../includes/header.php';
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch distinct users the logged-in user has chatted with
$query = "SELECT DISTINCT users.id, users.name, users.profile_picture 
          FROM messages 
          JOIN users ON (messages.sender_id = users.id OR messages.receiver_id = users.id) 
          WHERE (messages.sender_id = '$user_id' OR messages.receiver_id = '$user_id') 
          AND users.id != '$user_id'";

$result = mysqli_query($conn, $query);
?>

<div class="min-h-screen bg-gray-100 flex justify-center items-center">
    <div class="max-w-4xl w-full bg-white shadow-lg rounded-lg p-8">
        <h2 class="text-2xl font-bold mb-4 text-center">Messages</h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <ul class="divide-y divide-gray-200">
                <?php while ($chat_user = mysqli_fetch_assoc($result)): ?>
                    <li class="p-4 hover:bg-gray-100">
                        <a href="chat.php?user_id=<?php echo $chat_user['id']; ?>" class="flex items-center">
                            <img src="../assets/images/<?php echo $chat_user['profile_picture']; ?>" 
                                 alt="Profile Picture" class="w-12 h-12 rounded-full border">
                            <div class="ml-4">
                                <h4 class="text-lg font-semibold"><?php echo htmlspecialchars($chat_user['name']); ?></h4>
                                <p class="text-gray-500 text-sm">Click to view chat</p>
                            </div>
                        </a>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p class="text-gray-500 text-center">No messages yet.</p>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
