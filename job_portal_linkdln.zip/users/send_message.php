<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['receiver_id']) || !isset($_POST['message'])) {
    echo json_encode(["status" => "error", "message" => "Invalid request."]);
    exit();
}

$sender_id = $_SESSION['user_id'];
$receiver_id = $_POST['receiver_id'];
$message = mysqli_real_escape_string($conn, $_POST['message']);

// Insert the message into the database
$query_insert = "INSERT INTO messages (sender_id, receiver_id, message, created_at, is_read) 
                 VALUES ('$sender_id', '$receiver_id', '$message', NOW(), 0)";

if (mysqli_query($conn, $query_insert)) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to send message."]);
}
?>
