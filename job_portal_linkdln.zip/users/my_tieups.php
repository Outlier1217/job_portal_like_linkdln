<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/header.php';
include '../includes/db.php';

$user_id = $_SESSION['user_id'];

// Fetch all accepted tie-ups
$query = "SELECT users.id, users.name, users.profile_picture, users.is_online
          FROM tie_up_requests
          JOIN users ON (tie_up_requests.sender_id = users.id OR tie_up_requests.receiver_id = users.id)
          WHERE (tie_up_requests.sender_id = '$user_id' OR tie_up_requests.receiver_id = '$user_id')
          AND tie_up_requests.status = 'accepted'
          AND users.id != '$user_id'";

$result = mysqli_query($conn, $query);
?>

<div class="min-h-screen bg-gray-100 py-10 px-4 md:px-10">
    <div class="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">🤝 My Tie-Ups</h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php while ($tieup = mysqli_fetch_assoc($result)): ?>
                    <div class="bg-gray-50 p-6 rounded-lg shadow flex items-center">
                        <img src="../assets/images/<?php echo htmlspecialchars($tieup['profile_picture']); ?>" 
                             alt="Profile" class="w-16 h-16 rounded-full border">
                        <div class="ml-4">
                            <h4 class="text-lg font-semibold"><?php echo htmlspecialchars($tieup['name']); ?></h4>
                            <p class="<?php echo $tieup['is_online'] ? 'text-green-500' : 'text-red-500'; ?>">
                                <?php echo $tieup['is_online'] ? '🟢 Online' : '🔴 Offline'; ?>
                            </p>
                        </div>
                        <div class="ml-auto">
                            <a href="chat.php?user_id=<?php echo $tieup['id']; ?>" 
                               class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                                💬 Chat
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-500 text-center mt-6">No tie-ups found. Send requests to connect with others!</p>
        <?php endif; ?>
    </div>
</div>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>

<?php include '../includes/footer.php'; ?>
