<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit();
}

$reported_by = $_SESSION['user_id'];
$data = json_decode(file_get_contents("php://input"), true);
$post_id = $data['post_id'];

// Check if already reported
$check_sql = "SELECT * FROM reports WHERE reported_by = '$reported_by' AND post_id = '$post_id'";
$result = mysqli_query($conn, $check_sql);

if (mysqli_num_rows($result) > 0) {
    echo json_encode(["status" => "error", "message" => "Already reported"]);
} else {
    $sql = "INSERT INTO reports (reported_by, post_id, reason) VALUES ('$reported_by', '$post_id', 'Inappropriate Content')";
    mysqli_query($conn, $sql);
    echo json_encode(["status" => "success", "message" => "Post reported!"]);
}
?>
