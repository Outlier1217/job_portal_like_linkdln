<?php
session_start();
include '../includes/db.php';

// Redirect to login if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

include '../includes/header.php';

// Fetch logged-in user's email
$user_id = $_SESSION['user_id'];
$user_email = getUserEmail($user_id, $conn);

function getUserEmail($user_id, $conn) {
    $query = "SELECT email FROM users WHERE id = '$user_id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['email'] ?? "";
}

// Check if a success message should be displayed
$showPopup = isset($_SESSION['suggestion_success']);
unset($_SESSION['suggestion_success']);
?>

<div class="min-h-screen bg-gray-100 py-10 px-4 md:px-10">
    <div class="max-w-3xl mx-auto bg-white shadow-lg rounded-lg p-8">
        <h2 class="text-2xl font-bold text-gray-800 text-center">📩 Suggestion Box</h2>
        <p class="text-gray-600 text-center mt-2">We value your feedback! Share your suggestions with us.</p>

        <!-- Suggestion Form -->
        <form action="submit_suggestion.php" method="POST" class="mt-6">
            <label class="block text-gray-700 font-semibold">Your Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user_email); ?>" 
                   required readonly class="w-full p-2 border rounded mt-2 bg-gray-200">

            <label class="block text-gray-700 font-semibold mt-4">Your Suggestion:</label>
            <textarea name="suggestion" rows="5" required class="w-full p-2 border rounded mt-2" 
                      placeholder="Write your suggestion here..."></textarea>

            <button type="submit" class="bg-blue-500 text-white px-5 py-2 rounded-lg shadow-md hover:bg-blue-600 mt-4 w-full">
                📤 Submit Suggestion
            </button>
        </form>
    </div>
</div>

<!-- Success Popup -->
<?php if ($showPopup): ?>
    <div id="popup" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
        <div class="bg-white p-6 rounded-lg shadow-lg text-center">
            <h3 class="text-lg font-semibold text-gray-800">✅ Thank you!</h3>
            <p class="text-gray-600 mt-2">Your suggestion has been received.</p>
            <button onclick="closePopup()" class="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">OK</button>
        </div>
    </div>
    
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>
    <script>
        function closePopup() {
            document.getElementById("popup").style.display = "none";
        }
        setTimeout(closePopup, 3000); // Auto-close after 3 seconds
    </script>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
