<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['user_id'])) {
    die("Unauthorized access.");
}

$user_id = $_SESSION['user_id'];
$receiver_id = $_GET['user_id'];

// Fetch messages only between the logged-in user and the selected receiver
$query = "SELECT * FROM messages 
          WHERE (sender_id = '$user_id' AND receiver_id = '$receiver_id') 
             OR (sender_id = '$receiver_id' AND receiver_id = '$user_id') 
          ORDER BY created_at ASC";

$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_assoc($result)) {
    $alignment = ($row['sender_id'] == $user_id) ? "text-right" : "text-left";
    echo "<p class='$alignment'><strong>{$row['sender_id']}:</strong> {$row['message']}</p>";
}
?>
