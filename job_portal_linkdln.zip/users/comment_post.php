<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "Please LogIn First"]);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);
$user_id = $_SESSION['user_id'];
$post_id = $data['post_id'];
$comment = mysqli_real_escape_string($conn, $data['comment']);

$sql = "INSERT INTO comments (user_id, post_id, comment) VALUES ('$user_id', '$post_id', '$comment')";
if (mysqli_query($conn, $sql)) {
    echo json_encode(["status" => "success", "message" => "Comment added"]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>
