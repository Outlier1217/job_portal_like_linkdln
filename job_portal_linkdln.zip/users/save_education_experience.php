<?php
session_start();
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_POST['user_id'];
    $type = $_POST['type'];
    $institution = $_POST['institution'];
    $degree_or_role = $_POST['degree_or_role'];
    $job_role = $_POST['job_role'] ?: NULL;
    $current_role = $_POST['current_role'] ?: NULL;
    $current_post_role = $_POST['current_post_role'] ?: NULL;
    $start_date = $_POST['start_date'];
    $end_date = !empty($_POST['end_date']) ? $_POST['end_date'] : NULL;
    $description = $_POST['description'];

    // Insert data into education_experience table
    $query = "INSERT INTO education_experience (user_id, type, institution, degree_or_role, job_role, current_post_role, start_date, end_date, description) 
          VALUES ('$user_id', '$type', '$institution', '$degree_or_role', '$job_role', '$current_post_role', '$start_date', " . ($end_date ? "'$end_date'" : "NULL") . ", '$description')";


    if (mysqli_query($conn, $query)) {
        header("Location: education_experience.php?success=1");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
