<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit();
}

$user_id = $_SESSION['user_id'];
$data = json_decode(file_get_contents("php://input"), true);
$post_id = $data['post_id'];

// Check if already liked
$check_sql = "SELECT * FROM likes WHERE user_id = '$user_id' AND post_id = '$post_id'";
$result = mysqli_query($conn, $check_sql);

if (mysqli_num_rows($result) > 0) {
    // Unlike the post
    $delete_sql = "DELETE FROM likes WHERE user_id = '$user_id' AND post_id = '$post_id'";
    mysqli_query($conn, $delete_sql);
    echo json_encode(["status" => "unliked"]);
} else {
    // Like the post
    $insert_sql = "INSERT INTO likes (user_id, post_id) VALUES ('$user_id', '$post_id')";
    mysqli_query($conn, $insert_sql);
    echo json_encode(["status" => "liked"]);
}
?>
