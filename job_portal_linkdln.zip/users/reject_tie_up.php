<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: tie_up_requests.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$request_id = mysqli_real_escape_string($conn, $_POST['request_id']);

// Check if the request exists and belongs to the logged-in user
$query_check = "SELECT * FROM tie_up_requests WHERE id = '$request_id' AND receiver_id = '$user_id' AND status = 'pending'";
$result_check = mysqli_query($conn, $query_check);

if (mysqli_num_rows($result_check) > 0) {
    // Delete the request
    $query_delete = "DELETE FROM tie_up_requests WHERE id = '$request_id'";
    if (mysqli_query($conn, $query_delete)) {
        $_SESSION['success'] = "Tie-up request rejected successfully.";
    } else {
        $_SESSION['error'] = "Error rejecting the request.";
    }
} else {
    $_SESSION['error'] = "Invalid request.";
}

header("Location: tie_up_requests.php");
exit();
?>
