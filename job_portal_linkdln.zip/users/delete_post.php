<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['post_id'])) {
    header("Location: ../index.php");
    exit();
}

$post_id = $_POST['post_id'];
$delete_sql = "DELETE FROM jobs WHERE id = '$post_id' AND user_id = '".$_SESSION['user_id']."'";

if (mysqli_query($conn, $delete_sql)) {
    header("Location: ../index.php");
} else {
    echo "Error deleting post.";
}
?>
