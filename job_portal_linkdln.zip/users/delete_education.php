<?php
session_start();
include '../includes/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM education_experience WHERE id = '$id'";

    if (mysqli_query($conn, $query)) {
        header("Location: education_experience.php?deleted=1");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
