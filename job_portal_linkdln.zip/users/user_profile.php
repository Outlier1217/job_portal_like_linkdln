<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_GET['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

include '../includes/header.php';
include '../includes/db.php';

// Get user ID from URL
$view_user_id = mysqli_real_escape_string($conn, $_GET['user_id']);

// Fetch user details
$query = "SELECT name, email, profile_picture, qualifications, job_experience, employment_status, current_work_status, current_organization FROM users WHERE id = '$view_user_id'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "<p class='text-red-500 text-center mt-10'>User not found.</p>";
    include '../includes/footer.php';
    exit();
}

$user_data = mysqli_fetch_assoc($result);

// Fetch user job posts
$query_posts = "SELECT * FROM jobs WHERE user_id = '$view_user_id' ORDER BY created_at DESC";
$result_posts = mysqli_query($conn, $query_posts);
?>

<div class="min-h-screen bg-gray-100 py-10 px-4 md:px-10">
    <div class="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8">
        
        <!-- User Profile Section -->
        <div class="flex flex-col items-center text-center">
            <img src="../assets/images/<?php echo htmlspecialchars($user_data['profile_picture'] ?? 'default.png'); ?>" 
                 alt="Profile Picture" class="w-24 h-24 rounded-full border border-gray-300 shadow-lg">
            
            <h2 class="text-2xl font-bold mt-4 text-gray-800"><?php echo htmlspecialchars($user_data['name'] ?? 'Unknown User'); ?></h2>
            <p class="text-gray-600 text-sm"><?php echo htmlspecialchars($user_data['current_organization'] ?? 'Not Available'); ?></p>

            <div class="mt-4 text-gray-700 text-sm">
                <p><strong>Qualifications:</strong> 
                    <?php echo !empty($user_data['qualifications']) ? htmlspecialchars($user_data['qualifications']) : "Not added"; ?>
                </p>
                <p><strong>Job Experience:</strong> 
                    <?php echo !empty($user_data['job_experience']) ? htmlspecialchars($user_data['job_experience']) : "Not added"; ?>
                </p>
                <p><strong>Currently Working As:</strong> 
                    <?php echo !empty($user_data['current_work_status']) ? htmlspecialchars($user_data['current_work_status']) : "Not added"; ?>
                </p>
                
            </div>

            <?php 
// Check if the user is already tied up
$sender_id = $_SESSION['user_id'];
$query_tieup = "SELECT * FROM tie_up_requests 
                WHERE ((sender_id = '$sender_id' AND receiver_id = '$view_user_id') 
                OR (sender_id = '$view_user_id' AND receiver_id = '$sender_id')) 
                AND status = 'accepted'";
$result_tieup = mysqli_query($conn, $query_tieup);

// Check if the user is already tied up
$sender_id = $_SESSION['user_id'];
$query_tieup = "SELECT * FROM tie_up_requests 
                WHERE ((sender_id = '$sender_id' AND receiver_id = '$view_user_id') 
                OR (sender_id = '$view_user_id' AND receiver_id = '$sender_id'))";
$result_tieup = mysqli_query($conn, $query_tieup);

$tieup_status = null;
if ($result_tieup && mysqli_num_rows($result_tieup) > 0) {
    $tieup_data = mysqli_fetch_assoc($result_tieup);
    $tieup_status = $tieup_data['status'];
}

if ($tieup_status === 'accepted'): ?>
    <!-- Show Chat Button if Tie-Up is Accepted -->
    <div class="mt-6">
        <a href="chat.php?user_id=<?php echo $view_user_id; ?>" 
           class="bg-blue-500 text-white px-5 py-2 rounded-lg shadow-md hover:bg-blue-600">
            💬 Chat with <?php echo htmlspecialchars($user_data['name'] ?? 'User'); ?>
        </a>
    </div>
<?php elseif ($tieup_status === 'pending'): ?>
    <!-- Show "Request Sent" Button If Tie-Up Request is Pending -->
    <div class="mt-6">
        <button class="bg-gray-400 text-white px-5 py-2 rounded-lg shadow-md cursor-not-allowed" disabled>
            ✅ Request Sent
        </button>
    </div>
<?php else: ?>
    <!-- Show Tie-Up Request Button If No Request Exists -->
    <div class="mt-6">
        <form action="send_tie_up.php" method="POST">
            <input type="hidden" name="receiver_id" value="<?php echo $view_user_id; ?>">
            <button type="submit" class="bg-green-500 text-white px-5 py-2 rounded-lg shadow-md hover:bg-green-600">
                🤝 Send Tie-Up Request
            </button>
        </form>
    </div>
<?php endif; ?>


        </div>

        <!-- User Job Posts -->
        <div class="mt-10">
            <h3 class="text-xl font-semibold mb-4">
                <?php echo htmlspecialchars($user_data['name'] ?? 'User'); ?>'s Job Posts
            </h3>

            <?php if ($result_posts && mysqli_num_rows($result_posts) > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php while ($post = mysqli_fetch_assoc($result_posts)): ?>
                        <div class="bg-gray-50 p-6 rounded-lg shadow">
                            <h4 class="text-lg font-semibold"><?php echo htmlspecialchars($post['job_title']); ?></h4>
                            <p class="text-gray-600 mt-2"><?php echo htmlspecialchars($post['job_description']); ?></p>
                            <p class="text-sm text-gray-500 mt-1">Posted on: <?php echo date("F d, Y", strtotime($post['created_at'])); ?></p>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="text-gray-500">
                    <?php echo htmlspecialchars($user_data['name'] ?? 'User'); ?> hasn't posted any jobs yet.
                </p>
            <?php endif; ?>
        </div>
    </div>
</div>


<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>
<?php include '../includes/footer.php'; ?>
