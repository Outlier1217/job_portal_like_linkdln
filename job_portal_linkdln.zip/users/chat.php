<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
    die("<p class='text-center text-red-500 mt-10'>Invalid chat session. Please try again.</p>");
}

$sender_id = $_SESSION['user_id'];
$receiver_id = (int)$_GET['user_id'];

$stmt = $conn->prepare("SELECT * FROM tie_up_requests 
                       WHERE ((sender_id = ? AND receiver_id = ?) 
                       OR (sender_id = ? AND receiver_id = ?)) 
                       AND status = 'accepted'");
$stmt->bind_param("iiii", $sender_id, $receiver_id, $receiver_id, $sender_id);
$stmt->execute();
$result_check = $stmt->get_result();

if ($result_check->num_rows === 0) {
    ?>
    <div class="text-center mt-10 p-4">
        <p class="text-red-500 text-lg mb-4">You are not connected with this user.</p>
        <form action="send_tieup_request.php" method="POST" class="mt-4">
            <input type="hidden" name="receiver_id" value="<?php echo htmlspecialchars($receiver_id); ?>">
            <button type="submit" class="bg-green-500 text-white px-6 py-3 rounded-full shadow-md hover:bg-green-600 transition duration-200">
                🤝 Send Tie-Up Request
            </button>
        </form>
    </div>
    <?php
    include '../includes/footer.php';
    exit();
}

$stmt = $conn->prepare("SELECT name, profile_picture, is_online FROM users WHERE id = ?");
$stmt->bind_param("i", $receiver_id);
$stmt->execute();
$receiver = $stmt->get_result()->fetch_assoc();

$stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?");
$stmt->bind_param("ii", $receiver_id, $sender_id);
$stmt->execute();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Chat with <?php echo htmlspecialchars($receiver['name']); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        :root {
            --primary-color: #075E54;
            --sent-bg: #DCF8C6;
            --received-bg: #FFFFFF;
            --chat-bg: #ECE5DD;
        }

        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: system-ui, -apple-system, sans-serif;
            background: var(--chat-bg);
            overflow: hidden;
        }

        .chat-container {
            max-width: 600px;
            width: 100%;
            height: 100vh;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            position: relative;
        }

        .chat-header {
            position: sticky;
            top: 0;
            width: 100%;
            max-width: 600px;
            background: var(--primary-color);
            color: white;
            padding: 1rem;
            display: flex;
            align-items: center;
            z-index: 20;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .back-btn {
            font-size: 1.5rem;
            padding: 0.5rem;
            cursor: pointer;
            touch-action: manipulation;
        }

        .profile-pic {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin: 0 0.75rem;
            object-fit: cover;
        }

        .user-info h2 {
            font-size: 1.1rem;
            font-weight: 600;
        }

        .user-info p {
            font-size: 0.85rem;
            opacity: 0.9;
        }

        .chat-body {
            flex: 1;
            padding: 1rem;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            scrollbar-width: thin;
            height: calc(100vh - 120px); /* Adjust based on header + footer height */
        }

        .message {
            max-width: 80%;
            padding: 0.75rem;
            border-radius: 0.5rem;
            font-size: 0.95rem;
            word-wrap: break-word;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            position: relative;
        }

        .sent {
            align-self: flex-end;
            background: var(--sent-bg);
            border-bottom-right-radius: 0;
        }

        .received {
            align-self: flex-start;
            background: var(--received-bg);
            border-bottom-left-radius: 0;
            border: 1px solid #eee;
        }

        .chat-footer {
            position: sticky;
            bottom: 0;
            width: 100%;
            max-width: 600px;
            background: #F0F0F0;
            padding: 0.5rem 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            border-top: 1px solid #ddd;
            z-index: 20;
        }

        .message-input {
            flex: 1;
            padding: 0.75rem 1rem;
            border: none;
            border-radius: 1.5rem;
            background: white;
            font-size: 1rem;
            outline: none;
            resize: none;
            max-height: 100px;
            overflow-y: auto;
            min-height: 40px;
        }

        .send-btn {
            background: var(--primary-color);
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            font-size: 1.2rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            touch-action: manipulation;
        }

        @media (max-width: 600px) {
            .chat-container {
                max-width: 100%;
                box-shadow: none;
            }
            
            .chat-header {
                max-width: 100%;
            }
            
            .chat-footer {
                max-width: 100%;
                padding: 0.5rem;
            }
            
            .message {
                max-width: 85%;
                font-size: 0.9rem;
            }

            .chat-body {
                height: calc(100vh - 110px); /* Slightly smaller on mobile */
            }
        }
    </style>
</head>
<body>
<div class="chat-container">
    <div class="chat-header">
        <span class="back-btn" onclick="goBack()">⬅</span>
        <img src="../assets/images/<?php echo htmlspecialchars($receiver['profile_picture'] ?? 'default.png'); ?>" 
             alt="Profile" class="profile-pic">
        <div class="user-info">
            <h2><?php echo htmlspecialchars($receiver['name']); ?></h2>
            <p id="online-status">
                <?php echo ($receiver['is_online'] == 1) ? '🟢 Online' : '🔴 Offline'; ?>
            </p>
        </div>
    </div>

    <div id="messages" class="chat-body"></div>

    <div class="chat-footer">
        <textarea id="message" class="message-input" placeholder="Type a message..." rows="1" autocomplete="off"></textarea>
        <button id="send-btn" class="send-btn">📤</button>
    </div>
</div>

<script>
class ChatManager {
    constructor() {
        this.receiverId = <?php echo json_encode($receiver_id); ?>;
        this.messageInput = $('#message');
        this.messagesContainer = $('#messages');
        this.sendButton = $('#send-btn');
        this.lastMessageTime = 0;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadMessages();
        this.setupIntervals();
        this.handleViewportResize();
    }

    setupEventListeners() {
        const sendMessage = this.debounce(() => this.sendMessage(), 200);
        
        this.sendButton.on('click', sendMessage);
        this.messageInput.on('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        this.messageInput.on('input', function() {
            this.style.height = 'auto';
            this.style.height = `${Math.min(this.scrollHeight, 100)}px`; // Cap at 100px
        });

        // Handle focus to ensure visibility
        this.messageInput.on('focus', () => {
            setTimeout(() => {
                this.messagesContainer.scrollTop(this.messagesContainer[0].scrollHeight);
            }, 300); // Delay to account for keyboard animation
        });
    }

    setupIntervals() {
        setInterval(() => this.loadMessages(), 2000);
        setInterval(() => this.updateOnlineStatus(), 5000);
    }

    handleViewportResize() {
        const updateHeight = () => {
            const vh = window.innerHeight;
            document.documentElement.style.setProperty('--vh', `${vh}px`);
            this.messagesContainer.css('height', `calc(var(--vh, 100vh) - 120px)`);
        };

        window.addEventListener('resize', updateHeight);
        window.addEventListener('orientationchange', updateHeight);
        updateHeight();
    }

    async sendMessage() {
        const message = this.messageInput.val().trim();
        if (!message) return;

        try {
            const response = await $.post("send_message.php", {
                receiver_id: this.receiverId,
                message: message
            }, null, 'json');

            if (response.status === "success") {
                this.messageInput.val('');
                this.messageInput.css('height', 'auto');
                this.loadMessages();
            } else {
                alert('Failed to send message: ' + (response.message || 'Unknown error'));
            }
        } catch (error) {
            console.error('Send message error:', error);
            alert('An error occurred while sending your message');
        }
    }

    async loadMessages() {
        try {
            const data = await $.get(`fetch_messages.php?user_id=${this.receiverId}`);
            this.messagesContainer.html(data);
            const scrollHeight = this.messagesContainer[0].scrollHeight;
            if (Math.abs(this.messagesContainer.scrollTop() + this.messagesContainer.innerHeight() - scrollHeight) < 100) {
                this.messagesContainer.scrollTop(scrollHeight);
            }
        } catch (error) {
            console.error('Load messages error:', error);
        }
    }

    async updateOnlineStatus() {
        try {
            const status = await $.get(`fetch_online_status.php?user_id=${this.receiverId}`);
            $('#online-status').html(status);
        } catch (error) {
            console.error('Status update error:', error);
        }
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

function goBack() {
    window.history.back();
}

$(document).ready(() => new ChatManager());
</script>
</body>
</html>