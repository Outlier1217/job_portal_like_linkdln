<?php
session_start();
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['receiver_id'])) {
    $sender_id = $_SESSION['user_id'];
    $receiver_id = $_POST['receiver_id'];

    // Prevent sending duplicate requests
    $check_query = "SELECT * FROM tie_up_requests WHERE sender_id='$sender_id' AND receiver_id='$receiver_id'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $_SESSION['error'] = "You have already sent a request to this user.";
        header("Location: user_profile.php");
        exit();
    }

    // Insert tie-up request into the database
    $insert_query = "INSERT INTO tie_up_requests (sender_id, receiver_id, status) VALUES ('$sender_id', '$receiver_id', 'pending')";

    if (mysqli_query($conn, $insert_query)) {
        $_SESSION['success'] = "Tie-Up request sent successfully!";
        header("Location: user_profile.php");
    } else {
        $_SESSION['error'] = "Error sending request.";
        header("Location: all_users.php");
    }
}
?>
