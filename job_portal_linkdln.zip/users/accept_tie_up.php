<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access");
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_id'])) {
    $request_id = $_POST['request_id'];
    $query = "UPDATE tie_up_requests SET status = 'accepted' WHERE id = '$request_id'";

    if (mysqli_query($conn, $query)) {
        header("Location: tie_up_requests.php");
        exit();
    } else {
        echo "Error accepting request: " . mysqli_error($conn);
    }
}
?>
