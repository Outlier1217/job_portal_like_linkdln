<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

include '../includes/header.php';
include '../includes/db.php';

$user_id = $_SESSION['user_id'];

// Fetch user education & experience
$query = "SELECT * FROM education_experience WHERE user_id = '$user_id' ORDER BY start_date DESC";
$result = mysqli_query($conn, $query);
?>

<div class="min-h-screen bg-gray-100 py-10 px-4 md:px-10">
    <div class="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8">
        
        <h2 class="text-2xl font-bold text-gray-800">🎓 Education & Experience</h2>

        <!-- Add New Entry Form -->
        <form action="save_education_experience.php" method="POST" class="mt-6">
            <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">

            <!-- Type Selection -->
            <label class="block text-gray-700 font-semibold">Select Type:</label>
            <select name="type" required class="w-full p-2 border rounded mt-2">
                <option value="school">🏫 School</option>
                <option value="college">🎓 College</option>
                <option value="certification">📜 Certification</option>
                <option value="experience">💼 Experience</option>
                <option value="internship">🛠 Internship</option>
            </select>

            <!-- Institution/Company Name -->
            <label class="block text-gray-700 font-semibold mt-4">Institution/Company Name:</label>
            <input type="text" name="institution" required class="w-full p-2 border rounded mt-2" placeholder="Enter name">

            <!-- Degree/Role -->
            <label class="block text-gray-700 font-semibold mt-4">Degree/Certificate:</label>
            <input type="text" name="degree_or_role" required class="w-full p-2 border rounded mt-2" placeholder="Degree or Certificate Name">

            <!-- Job Role/Post -->
            <label class="block text-gray-700 font-semibold mt-4">Job Role/Post:</label>
            <input type="text" name="job_role" class="w-full p-2 border rounded mt-2" placeholder="Job Role/Post (Optional)">

            <!-- Current Role/Post -->
            <label class="block text-gray-700 font-semibold mt-4">Current Role/Post:</label>
            <input type="text" name="current_post_role" class="w-full p-2 border rounded mt-2" placeholder="Current Role/Post (Optional)">

            <!-- Start & End Dates -->
            <label class="block text-gray-700 font-semibold mt-4">Start Date:</label>
            <input type="date" name="start_date" required class="w-full p-2 border rounded mt-2">

            <label class="block text-gray-700 font-semibold mt-4">End Date (Leave blank if ongoing):</label>
            <input type="date" name="end_date" class="w-full p-2 border rounded mt-2">

            <!-- Description -->
            <label class="block text-gray-700 font-semibold mt-4">Description:</label>
            <textarea name="description" rows="3" class="w-full p-2 border rounded mt-2" placeholder="Additional details"></textarea>

            <!-- Submit Button -->
            <button type="submit" class="bg-blue-500 text-white px-5 py-2 rounded-lg shadow-md hover:bg-blue-600 mt-4">
                ➕ Add Entry
            </button>
        </form>

        <!-- Display User Entries -->
        <h3 class="text-xl font-semibold mt-10">📜 Your Entries</h3>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <table class="w-full mt-4 bg-white shadow-lg rounded-lg">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="p-2">Type</th>
                        <th class="p-2">Institution</th>
                        <th class="p-2">Role/Degree</th>
                        <th class="p-2">Job Role</th>
                        <th class="p-2">Current Role</th>
                        <th class="p-2">Start - End</th>
                        <th class="p-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr class="border-b">
                            <td class="p-2"><?php echo ucfirst($row['type']); ?></td>
                            <td class="p-2"><?php echo htmlspecialchars($row['institution']); ?></td>
                            <td class="p-2"><?php echo htmlspecialchars($row['degree_or_role']); ?></td>
                            <td class="p-2"><?php echo htmlspecialchars($row['job_role']); ?></td>
                            <td class="p-2"><?php echo htmlspecialchars($row['current_post_role']); ?></td>
                            <td class="p-2"><?php echo date("M Y", strtotime($row['start_date'])) . " - " . ($row['end_date'] ? date("M Y", strtotime($row['end_date'])) : "Present"); ?></td>
                            <td class="p-2">
                                <a href="delete_education.php?id=<?php echo $row['id']; ?>" class="text-red-500">❌ Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-gray-500 mt-4">No entries found. Start adding your education and experience!</p>
        <?php endif; ?>
    </div>
</div>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>
<?php include '../includes/footer.php'; ?>
