<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/header.php';
?>

<div class="container mx-auto mt-10">
    <h2 class="text-3xl font-bold">Post a Job or Seek a Job</h2>
    <form action="post_job_process.php" method="POST" class="mt-6 bg-white p-6 rounded shadow">
        <input type="text" name="job_title" placeholder=" Title" required class="w-full p-2 border rounded mb-3">
        <textarea name="job_description" placeholder="Description" required class="w-full p-2 border rounded mb-3"></textarea>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Post or Seek a Job</button>
    </form>
</div>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>

<?php include '../includes/footer.php'; ?>
