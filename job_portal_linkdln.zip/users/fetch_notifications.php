<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch unread messages
$query_messages = "SELECT messages.sender_id, COUNT(messages.id) AS unread_count, users.name 
                   FROM messages 
                   JOIN users ON messages.sender_id = users.id 
                   WHERE messages.receiver_id = '$user_id' AND messages.is_read = 0
                   GROUP BY messages.sender_id";
$result_messages = mysqli_query($conn, $query_messages);

if (mysqli_num_rows($result_messages) > 0) {
    while ($message = mysqli_fetch_assoc($result_messages)) {
        echo "<p><strong>" . htmlspecialchars($message['name']) . "</strong> sent you <strong>" . $message['unread_count'] . "</strong> new message(s).</p>";
    }
} else {
    echo "<p>No new messages.</p>";
}
?>
