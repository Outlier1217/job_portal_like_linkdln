<?php
session_start();
include '../includes/db.php';

// Redirect if not logged in or post_id is missing
if (!isset($_SESSION['user_id']) || !isset($_GET['post_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$post_id = $_GET['post_id'];

// Fetch the job post
$query = "SELECT * FROM jobs WHERE id = '$post_id' AND user_id = '$user_id'";
$result = mysqli_query($conn, $query);
$post = mysqli_fetch_assoc($result);

if (!$post) {
    echo "<div class='text-center text-red-500 mt-10'>Post not found!</div>";
    exit();
}

// Handle form submission via AJAX
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $job_title = mysqli_real_escape_string($conn, $_POST['job_title']);
    $job_description = mysqli_real_escape_string($conn, $_POST['job_description']);

    $update_sql = "UPDATE jobs SET job_title = '$job_title', job_description = '$job_description' WHERE id = '$post_id' AND user_id = '$user_id'";
    
    if (mysqli_query($conn, $update_sql)) {
        echo json_encode(["status" => "success"]);
        exit();
    } else {
        echo json_encode(["status" => "error"]);
        exit();
    }
}

include '../includes/header.php';
?>

<div class="min-h-screen bg-gray-100 flex items-center justify-center px-4">
    <div class="max-w-lg w-full bg-white shadow-lg rounded-lg p-6">
        <h2 class="text-2xl font-bold text-gray-800 text-center mb-4">✏️ Edit Job Post</h2>

        <form id="edit-form" class="space-y-4">
            <label class="block text-gray-700 font-semibold">Job Title</label>
            <input type="text" name="job_title" id="job_title" value="<?php echo htmlspecialchars($post['job_title']); ?>" 
                   class="w-full p-3 border rounded-lg focus:ring focus:ring-blue-200" required>

            <label class="block text-gray-700 font-semibold">Job Description</label>
            <textarea name="job_description" id="job_description" rows="4" 
                      class="w-full p-3 border rounded-lg focus:ring focus:ring-blue-200" required><?php echo htmlspecialchars($post['job_description']); ?></textarea>

            <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition duration-300">
                ✅ Update Post
            </button>
        </form>

        <a href="../dashboard.php" class="block text-center text-gray-500 mt-4 hover:text-blue-500">🔙 Back to Dashboard</a>
    </div>
</div>

<!-- Confirmation Popup -->
<div id="confirmation-popup" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg text-center">
        <h3 class="text-xl font-bold text-gray-800">✅ Post Updated Successfully!</h3>
        <p class="text-gray-600 mt-2">Redirecting to Dashboard...</p>
    </div>
</div>

<script>
document.getElementById("edit-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent default form submission

    if (!confirm("Are you sure you want to update this post?")) {
        return;
    }

    let formData = new FormData(this);
    fetch("", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            document.getElementById("confirmation-popup").classList.remove("hidden");
            setTimeout(() => {
                window.location.href = "dashboard.php";
            }, 2000);
        } else {
            alert("Error updating post. Please try again.");
        }
    })
    .catch(error => console.error("Error:", error));
});
</script>

<?php include '../includes/footer.php'; ?>
