<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/header.php';
include '../includes/db.php';

// Fetch user details
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = '$user_id'";
$result = mysqli_query($conn, $query);
$user_data = mysqli_fetch_assoc($result);
?>

<div class="min-h-screen bg-gray-100 flex justify-center items-center px-4">
    <div class="max-w-2xl w-full bg-white shadow-lg rounded-lg p-8">
        <h2 class="text-2xl font-bold mb-4">Edit Profile</h2>

        <form action="update_profile.php" method="POST" enctype="multipart/form-data">
            <div class="mb-4">
                <label class="block text-gray-700">Full Name</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($user_data['name']); ?>" required 
                       class="w-full p-2 border rounded">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700">Email</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required 
                       class="w-full p-2 border rounded">
            </div>

            <!-- Profile Picture Upload -->
            <div class="mb-4">
                <label class="block text-gray-700">Profile Picture</label>
                <input type="file" name="profile_picture" accept="image/*" class="w-full p-2 border rounded">
                <img src="../assets/images/<?php echo htmlspecialchars($user_data['profile_picture']); ?>" 
                     alt="Profile Picture" class="w-20 h-20 rounded-full mt-2 border">
            </div>

            <!-- Qualifications -->
            <div class="mb-4">
                <label class="block text-gray-700">Qualifications</label>
                <textarea name="qualifications" class="w-full p-2 border rounded"><?php echo htmlspecialchars($user_data['qualifications']); ?></textarea>
            </div>

            <!-- Job Experience -->
            <div class="mb-4">
                <label class="block text-gray-700">Total Experience</label>
                <textarea name="job_experience" class="w-full p-2 border rounded"><?php echo htmlspecialchars($user_data['job_experience']); ?></textarea>
            </div>

            <!-- Employment Status -->
            <div class="mb-4">
                <label class="block text-gray-700">Employment Status</label>
                <select name="employment_status" class="w-full p-2 border rounded">
                    <option value="Employed" <?php if ($user_data['employment_status'] == 'Employed') echo 'selected'; ?>>Employed</option>
                    <option value="Self-Employed" <?php if ($user_data['employment_status'] == 'Self-Employed') echo 'selected'; ?>>Self-Employed</option>
                    <option value="Student" <?php if ($user_data['employment_status'] == 'Student') echo 'selected'; ?>>Student</option>
                </select>
            </div>

            <!-- Current Work Status -->
            <div class="mb-4">
                <label class="block text-gray-700">Current Status of Work</label>
                <textarea name="current_work_status" class="w-full p-2 border rounded"><?php echo htmlspecialchars($user_data['current_work_status']); ?></textarea>
            </div>

            <!-- Current Organization Name -->
            <div class="mb-4">
                <label class="block text-gray-700">Current Organization Name</label>
                <input type="text" name="current_organization" value="<?php echo htmlspecialchars($user_data['current_organization'] ?? ''); ?>" 
                       class="w-full p-2 border rounded">
            </div>

            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded w-full hover:bg-blue-700">
                Update Profile
            </button>
        </form>
    </div>
</div>


<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>

<?php include '../includes/footer.php'; ?>
