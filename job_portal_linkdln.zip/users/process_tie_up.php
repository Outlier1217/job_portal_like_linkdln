<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['request_id']) || !isset($_POST['action'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$request_id = $_POST['request_id'];
$action = $_POST['action'];

// Process tie-up request
if ($action === "accept") {
    $query = "UPDATE tie_up_requests SET status = 'accepted' WHERE id = '$request_id' AND receiver_id = '$user_id'";
} elseif ($action === "reject") {
    $query = "DELETE FROM tie_up_requests WHERE id = '$request_id' AND receiver_id = '$user_id'";
}

if (mysqli_query($conn, $query)) {
    header("Location: tie_up_requests.php?success=1");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
