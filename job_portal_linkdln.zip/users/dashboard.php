<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/header.php';
include '../includes/db.php';

// Fetch user details
$user_id = $_SESSION['user_id'];
$query = "SELECT u.name, u.profile_picture, u.qualifications, u.job_experience, 
                 u.employment_status, u.current_work_status, u.current_organization,
                 (SELECT e.current_post_role 
                  FROM education_experience e 
                  WHERE e.user_id = u.id 
                  ORDER BY e.start_date DESC 
                  LIMIT 1) AS current_post_role
          FROM users u
          WHERE u.id = '$user_id'";

$result = mysqli_query($conn, $query);
$user_data = mysqli_fetch_assoc($result);

// Fetch user's job posts
$query_posts = "SELECT * FROM jobs WHERE user_id = '$user_id' ORDER BY created_at DESC";
$result_posts = mysqli_query($conn, $query_posts);



// Fetch tie-up users
$query_accepted = "SELECT users.id, users.name, users.profile_picture, users.is_online,
                          (SELECT COUNT(*) FROM messages WHERE sender_id = users.id AND receiver_id = '$user_id' AND is_read = 0) AS unread_messages
                   FROM tie_up_requests 
                   JOIN users ON (tie_up_requests.sender_id = users.id OR tie_up_requests.receiver_id = users.id) 
                   WHERE (tie_up_requests.sender_id = '$user_id' OR tie_up_requests.receiver_id = '$user_id') 
                   AND tie_up_requests.status = 'accepted' 
                   AND users.id != '$user_id'";
$result_accepted = mysqli_query($conn, $query_accepted);

// Fetch user education & experience
$query_edu_exp = "SELECT * FROM education_experience WHERE user_id = '$user_id' ORDER BY start_date DESC";
$result_edu_exp = mysqli_query($conn, $query_edu_exp);
?>

<div class="min-h-screen bg-gray-100 py-10 px-4 md:px-10">
    <div class="max-w-5xl mx-auto bg-white shadow-lg rounded-lg p-8">
        
        <!-- Profile Section -->
        <div class="flex flex-col items-center text-center">
            <img src="../assets/images/<?php echo $user_data['profile_picture']; ?>" 
                 alt="Profile Picture" 
                 class="w-24 h-24 rounded-full border border-gray-300 shadow-lg">
            
                 <h2 class="text-2xl font-bold mt-4 text-gray-800"><?php echo htmlspecialchars($user_data['name']); ?></h2>
<p class="text-gray-500 text-sm">
    <?php echo isset($user_data['current_post_role']) && !empty($user_data['current_post_role']) 
        ? htmlspecialchars($user_data['current_post_role']) 
        : "Not specified"; ?>
</p>


            <div class="mt-4 text-gray-700 text-sm">
                <p><strong>Qualifications:- </strong> <?php echo $user_data['qualifications'] ? $user_data['qualifications'] : "Not added"; ?></p>
                <p><strong>Total Experience:- </strong> <?php echo $user_data['job_experience'] ? $user_data['job_experience'] : "Not added"; ?></p>
                <p><strong>Employment Status:- </strong> <?php echo $user_data['employment_status'] ? $user_data['employment_status'] : "Not added"; ?></p>
                    
                
                
                <p><strong>Organization Name:- </strong> <?php echo $user_data['current_organization'] ? $user_data['current_organization'] : "Not added"; ?></p>
            </div>

            <div class="mt-6 flex space-x-4">
                <a href="edit_profile.php" class="bg-blue-500 text-white px-5 py-2 rounded-lg shadow-md hover:bg-blue-600">
                    Edit Profile
                </a>
                <a href="../auth/logout.php" class="bg-red-500 text-white px-5 py-2 rounded-lg shadow-md hover:bg-red-600">
                    Logout
                </a>
            </div>
        </div>

        <!-- Dashboard Sections -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div class="p-6 bg-gray-50 shadow rounded-lg text-center">
                <h3 class="text-xl font-semibold mb-2">Seek A Job</h3>
                <p class="text-gray-600 text-sm">Share Your Job Requirement</p>
                <a href="post_job.php" class="block mt-3 bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
    Post Your Need
</a>

            </div>

            <div class="p-6 bg-gray-50 shadow rounded-lg text-center">
                <h3 class="text-xl font-semibold mb-2">Post a Job</h3>
                <p class="text-gray-600 text-sm">Create a job to Help the candidates.</p>
                <a href="post_job.php" class="mt-3 inline-block bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                    Create Job Post
                </a>
            </div>

            <div class="p-6 bg-gray-50 shadow rounded-lg text-center">
                <h3 class="text-xl font-semibold mb-2">Add Education & Experience</h3>
                <p class="text-gray-600 text-sm"></p>
                <a href="education_experience.php" class="mt-3 inline-block bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                Add Education
                </a>
            </div>

            <div class="p-6 bg-gray-50 shadow rounded-lg text-center">
                <h3 class="text-xl font-semibold mb-2">Tie-Up Request</h3>
                <p class="text-gray-600 text-sm">View All Request</p>
                <a href="tie_up_requests.php" class="mt-3 inline-block bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                View Tie-Up Requests
                </a>
            </div>

            <div class="p-6 bg-gray-50 shadow rounded-lg text-center">
                <h3 class="text-xl font-semibold mb-2">Find & Tie-Up</h3>
                <p class="text-gray-600 text-sm">Send tie-up requests to other users.</p>
                <a href="all_users.php" class="block mt-3 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    View All Users
                </a>
            </div>

            <div class="p-6 bg-gray-50 shadow rounded-lg text-center">
                <h3 class="text-xl font-semibold mb-2">All Chat History</h3>
                <p class="text-gray-600 text-sm">Click to see.</p>
                <a href="chat_history.php" class="block mt-3 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    Chat History
                </a>
            </div>
        </div>

        <!-- My Job Posts -->
        <div class="mt-10">
            <h3 class="text-xl font-semibold mb-4">My Job Posts</h3>
            <?php if (mysqli_num_rows($result_posts) > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php while ($post = mysqli_fetch_assoc($result_posts)): ?>
                        <div class="bg-gray-50 p-6 rounded-lg shadow">
                            <h4 class="text-lg font-semibold"><?php echo $post['job_title']; ?></h4>
                            <p class="text-gray-600 mt-2"><?php echo $post['job_description']; ?></p>
                            <p class="text-sm text-gray-500 mt-1">Posted on: <?php echo date("F d, Y", strtotime($post['created_at'])); ?></p>

                            <div class="mt-4 flex space-x-4">
                                <a href="edit_post.php?post_id=<?php echo $post['id']; ?>" 
                                   class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">
                                    ✏️ Edit
                                </a>
                                <form action="delete_post.php" method="POST" onsubmit="return confirm('Are you sure?');">
                                    <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                    <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">
                                        🗑️ Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="text-gray-500">You haven't posted any jobs yet.</p>
            <?php endif; ?>
        </div>

        <!-- Online Users (Accepted Tie-Ups) -->
        <div class="mt-10">
            <h3 class="text-xl font-semibold mb-4">Connected Users (Online)</h3>
            <?php
            $query_accepted = "SELECT users.id, users.name, users.profile_picture 
                               FROM tie_up_requests 
                               JOIN users ON (tie_up_requests.sender_id = users.id OR tie_up_requests.receiver_id = users.id) 
                               WHERE (tie_up_requests.sender_id = '$user_id' OR tie_up_requests.receiver_id = '$user_id') 
                               AND tie_up_requests.status = 'accepted' 
                               AND users.id != '$user_id'";
            $result_accepted = mysqli_query($conn, $query_accepted);
            ?>

            <?php if (mysqli_num_rows($result_accepted) > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php while ($user = mysqli_fetch_assoc($result_accepted)): ?>
                        <div class="bg-gray-50 p-6 rounded-lg shadow">
                            <div class="flex items-center">
                                <img src="../assets/images/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                     alt="Profile Picture" class="w-16 h-16 rounded-full border">
                                <div class="ml-4">
                                    <h4 class="text-lg font-semibold">
    <a href="user_profile.php?user_id=<?php echo $user['id']; ?>" class="text-blue-500 hover:underline">
        <?php echo htmlspecialchars($user['name']); ?>
    </a>
</h4>

                                    <span class="text-green-500">🟢 Online</span>
                                </div>
                            </div>
                            <div class="mt-4">
                                <a href="chat.php?user_id=<?php echo $user['id']; ?>" 
                                   class="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                                    💬 Chat Now
                                </a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="text-gray-500">No connected users yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>


<!-- Message Notifications -->
<div class="mt-10">
<div id="message-notifications"></div>

    <h3 class="text-xl font-semibold mb-4">📩 Message Notifications</h3>

    <?php
    // Fetch unread messages
    $query_messages = "SELECT messages.id, messages.sender_id, messages.message, messages.created_at, 
                              users.name, users.profile_picture
                       FROM messages 
                       JOIN users ON messages.sender_id = users.id 
                       WHERE messages.receiver_id = '$user_id' AND messages.is_read = 0
                       ORDER BY messages.created_at DESC";
    $result_messages = mysqli_query($conn, $query_messages);
    ?>

    <?php if (mysqli_num_rows($result_messages) > 0): ?>
        <div class="bg-gray-50 p-6 rounded-lg shadow">
            <ul class="divide-y divide-gray-300">
                <?php while ($message = mysqli_fetch_assoc($result_messages)): ?>
                    <li class="py-4 flex items-center">
                        <img src="../assets/images/<?php echo htmlspecialchars($message['profile_picture']); ?>" 
                             alt="Profile Picture" class="w-10 h-10 rounded-full border">
                        <div class="ml-4">
                            <h4 class="text-lg font-semibold">
                                <a href="user_profile.php?user_id=<?php echo $message['sender_id']; ?>" 
                                   class="text-blue-500 hover:underline">
                                    <?php echo htmlspecialchars($message['name']); ?>
                                </a>
                            </h4>
                            <p class="text-gray-600 text-sm truncate w-48"><?php echo htmlspecialchars($message['message']); ?></p>
                            <p class="text-gray-500 text-xs"><?php echo date("F d, Y - h:i A", strtotime($message['created_at'])); ?></p>
                        </div>
                        <div class="ml-auto">
                            <a href="chat.php?user_id=<?php echo $message['sender_id']; ?>" 
                               class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                                💬 Reply
                            </a>
                        </div>
                    </li>
                <?php endwhile; ?>
            </ul>
        </div>
    <?php else: ?>
        <p class="text-gray-500">No new messages.</p>
    <?php endif; ?>
</div>



<!-- Connected Users -->
<h3 class="text-xl font-semibold mb-4">Connected Users</h3>

<?php if (mysqli_num_rows($result_accepted) > 0): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <?php while ($user = mysqli_fetch_assoc($result_accepted)): ?>
            <div class="bg-gray-50 p-6 rounded-lg shadow">
                <div class="flex items-center">
                    <img src="../assets/images/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                         alt="Profile Picture" class="w-16 h-16 rounded-full border">
                    <div class="ml-4">
                        <h4 class="text-lg font-semibold">
    <a href="user_profile.php?user_id=<?php echo $user['id']; ?>" class="text-blue-500 hover:underline">
        <?php echo htmlspecialchars($user['name']); ?>
    </a>
</h4>

                        <span class="<?php echo $user['is_online'] ? 'text-green-500' : 'text-red-500'; ?>">
                            <?php echo $user['is_online'] ? '🟢 Online' : '🔴 Offline'; ?>
                        </span>
                        <?php if ($user['unread_messages'] > 0): ?>
                            <span class="ml-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs">
                                <?php echo $user['unread_messages']; ?> New Message(s)
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mt-4">
                    <a href="chat.php?user_id=<?php echo $user['id']; ?>" 
                       class="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                        💬 Message
                    </a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
<?php else: ?>
    <p class="text-gray-500">No connected users yet.</p>
<?php endif; ?>

<!-- User's Education & Experience -->
<div class="mt-10">
            <h3 class="text-xl font-semibold mb-4">🎓 Education & Experience</h3>

            <?php if (mysqli_num_rows($result_edu_exp) > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php while ($row = mysqli_fetch_assoc($result_edu_exp)): ?>
                        <div class="bg-gray-50 p-6 rounded-lg shadow">
                            <h4 class="text-lg font-semibold"><?php echo ucfirst($row['type']); ?></h4>
                            <p class="text-gray-600"><?php echo htmlspecialchars($row['institution']); ?></p>
                            <p class="text-gray-500"><?php echo htmlspecialchars($row['degree_or_role']); ?></p>
                            <p class="text-gray-500"><?php echo date("M Y", strtotime($row['start_date'])) . " - " . ($row['end_date'] ? date("M Y", strtotime($row['end_date'])) : "Present"); ?></p>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="text-gray-500">No education or experience added.</p>
            <?php endif; ?>
        </div>

    </div>
</div>

<script>
    // Fetch new messages every 10 seconds
    setInterval(function () {
        fetch("fetch_notifications.php")
            .then(response => response.text())
            .then(data => {
                document.getElementById("message-notifications").innerHTML = data;
            });
    }, 10000); // Refresh every 10 seconds
</script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>



<?php include '../includes/footer.php'; ?>
