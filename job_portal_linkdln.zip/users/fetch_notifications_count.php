<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["count" => 0]);
    exit();
}

$user_id = $_SESSION['user_id'];

// Count pending tie-up requests
$query = "SELECT COUNT(*) AS count FROM tie_up_requests WHERE receiver_id = '$user_id' AND status = 'pending'";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

// Send JSON response
echo json_encode(["count" => (int)$data['count']]);
?>
