<?php
session_start();
include 'includes/db.php';

$query = isset($_GET['query']) ? mysqli_real_escape_string($conn, $_GET['query']) : '';

if ($query == '') {
    echo '<p class="text-gray-500 p-4">Please enter a search term.</p>';
    exit;
}

// Search users and job posts
$sql = "SELECT id, name, profile_picture FROM users WHERE name LIKE '%$query%' 
        UNION 
        SELECT id, job_title AS name, NULL FROM jobs WHERE job_title LIKE '%$query%'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $profilePic = $row['profile_picture'] ? "assets/images/{$row['profile_picture']}" : "assets/default-user.png";
        echo '<div class="p-4 border-b flex items-center">
                <img src="'.$profilePic.'" alt="Profile" class="w-8 h-8 rounded-full mr-3">
                <a href="users/user_profile.php?user_id='.$row['id'].'" class="text-blue-500 hover:underline">'.$row['name'].'</a>
              </div>';
    }
} else {
    echo '<p class="text-gray-500 p-4">No results found. Try another search.</p>';
}
?>
