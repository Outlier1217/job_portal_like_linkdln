<?php
include 'db.php';

if (isset($_GET['id'])) {
    $message_id = intval($_GET['id']);

    // Delete the message
    if ($conn->query("DELETE FROM messages WHERE id = $message_id")) {
        header("Location: messages.php?message=Message deleted successfully");
    } else {
        echo "Error deleting message: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
