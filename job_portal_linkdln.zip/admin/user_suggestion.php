<?php
session_start();
include 'header.php';

include 'db.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../auth/admin_login.php");
    exit();
}

// Fetch all user suggestions
$query = "SELECT id, email, suggestion, created_at FROM suggestions ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
?>

<div class="min-h-screen bg-gray-100 py-10 px-4 md:px-10">
    <div class="max-w-5xl mx-auto bg-white shadow-lg rounded-lg p-8">
        <h2 class="text-2xl font-bold text-gray-800 text-center">📩 User Suggestions</h2>
        <p class="text-gray-600 text-center mt-2">Here are the suggestions submitted by users.</p>

        <!-- Display Suggestions -->
        <?php if (mysqli_num_rows($result) > 0): ?>
            <table class="w-full mt-6 bg-white shadow-lg rounded-lg">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="p-2">User Email</th>
                        <th class="p-2">Suggestion</th>
                        <th class="p-2">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr class="border-b">
                            <td class="p-2"><?php echo htmlspecialchars($row['email']); ?></td>
                            <td class="p-2"><?php echo htmlspecialchars($row['suggestion']); ?></td>
                            <td class="p-2"><?php echo date("F d, Y - h:i A", strtotime($row['created_at'])); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-gray-500 mt-4 text-center">No suggestions found.</p>
        <?php endif; ?>
    </div>
</div>


