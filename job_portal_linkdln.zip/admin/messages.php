
<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}
?>





<?php
include 'header.php';

include 'db.php';

$result = $conn->query("SELECT messages.id, users.name AS sender, messages.message, messages.created_at 
                        FROM messages 
                        JOIN users ON messages.sender_id = users.id 
                        ORDER BY messages.created_at DESC");
?>

<div class="md:ml-1/5 p-6">
    <h2 class="text-2xl font-bold mb-4">Messages</h2>
    <table class="min-w-full bg-white shadow-md rounded">
        <thead>
            <tr class="bg-gray-200">
                <th class="p-2">ID</th>
                <th class="p-2">Sender</th>
                <th class="p-2">Message</th>
                <th class="p-2">Date</th>
                <th class="p-2">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr class="border-b">
                    <td class="p-2"><?php echo $row['id']; ?></td>
                    <td class="p-2"><?php echo $row['sender']; ?></td>
                    <td class="p-2"><?php echo substr($row['message'], 0, 50) . '...'; ?></td>
                    <td class="p-2"><?php echo $row['created_at']; ?></td>
                    <td class="p-2">
                        <a href="delete_message.php?id=<?php echo $row['id']; ?>" class="bg-red-500 text-white px-3 py-1 rounded">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
