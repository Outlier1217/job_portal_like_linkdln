<?php
include 'db.php';
if (isset($_GET['id'])) {
    $comment_id = $_GET['id'];
    $conn->query("DELETE FROM comments WHERE id = '$comment_id'");
    header("Location: comments.php");
}
?>
