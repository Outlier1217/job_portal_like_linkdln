<?php
// Database Configuration
if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
}
if (!defined('DB_USER')) {
    define('DB_USER', 'root'); // Change this if needed
}
if (!defined('DB_PASS')) {
    define('DB_PASS', ''); // Change this if you set a password
}
if (!defined('DB_NAME')) {
    define('DB_NAME', 'job_portal');
}

// Start session (uncomment if needed, but ensure it's not started elsewhere)
// if (session_status() === PHP_SESSION_NONE) {
//     session_start();
// }

// Connect to the database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Base URL for the project
if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://localhost/joballoc/');
}