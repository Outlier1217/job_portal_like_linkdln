<?php
include 'db.php';

if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']);

    // Delete all related records first
    $conn->query("DELETE FROM messages WHERE sender_id = $user_id OR receiver_id = $user_id");
    $conn->query("DELETE FROM comments WHERE user_id = $user_id");
    $conn->query("DELETE FROM jobs WHERE user_id = $user_id");
    $conn->query("DELETE FROM reports WHERE reported_by = $user_id OR reported_user = $user_id");
    $conn->query("DELETE FROM tie_up_requests WHERE sender_id = $user_id OR receiver_id = $user_id");

    // Now delete the user
    if ($conn->query("DELETE FROM users WHERE id = $user_id")) {
        header("Location: dashboard.php?message=User deleted successfully");
    } else {
        echo "Error deleting user: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
