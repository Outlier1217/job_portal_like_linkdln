
<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}
?>




<?php
include 'header.php';
include 'db.php';

$result = $conn->query("SELECT * FROM users");
?>

<div class="p-6 max-w-6xl mx-auto">
    <h2 class="text-3xl font-bold mb-6 text-center text-gray-700">👥 User Management</h2>

    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        <table class="min-w-full border border-gray-200">
            <thead class="bg-blue-600 text-white">
                <tr>
                    <th class="p-3 text-left">ID</th>
                    <th class="p-3 text-left">Name</th>
                    <th class="p-3 text-left">Email</th>
                    <th class="p-3 text-left">Status</th>
                    <th class="p-3 text-center">Actions</th>
                </tr>
            </thead>
            <tbody class="text-gray-700">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr class="border-b hover:bg-gray-100 transition">
                        <td class="p-3"><?php echo $row['id']; ?></td>
                        <td class="p-3"><?php echo $row['name']; ?></td>
                        <td class="p-3"><?php echo $row['email']; ?></td>
                        <td class="p-3"><?php echo $row['employment_status']; ?></td>
                        <td class="p-3 text-center">
                            <a href="delete_user.php?id=<?php echo $row['id']; ?>" 
                               class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition">
                               ❌ Delete
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>


