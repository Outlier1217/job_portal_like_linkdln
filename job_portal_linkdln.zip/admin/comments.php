
<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}
?>





<?php
include 'header.php';

include 'db.php';

$result = $conn->query("SELECT comments.id, users.name, comments.comment, comments.created_at 
                        FROM comments JOIN users ON comments.user_id = users.id ORDER BY comments.created_at DESC");
?>

<div class="md:ml-1/5 p-6">
    <h2 class="text-2xl font-bold mb-4">Comments</h2>
    <table class="min-w-full bg-white shadow-md rounded">
        <thead>
            <tr class="bg-gray-200">
                <th class="p-2">ID</th>
                <th class="p-2">User</th>
                <th class="p-2">Comment</th>
                <th class="p-2">Date</th>
                <th class="p-2">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr class="border-b">
                    <td class="p-2"><?php echo $row['id']; ?></td>
                    <td class="p-2"><?php echo $row['name']; ?></td>
                    <td class="p-2"><?php echo $row['comment']; ?></td>
                    <td class="p-2"><?php echo $row['created_at']; ?></td>
                    <td class="p-2">
                        <a href="delete_comment.php?id=<?php echo $row['id']; ?>" class="bg-red-500 text-white px-3 py-1 rounded">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
