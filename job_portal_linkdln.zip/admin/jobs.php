<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}
?>





<?php
include 'header.php';

include 'db.php';

$result = $conn->query("SELECT jobs.id, jobs.job_title, jobs.job_description, jobs.created_at, users.name 
                        FROM jobs JOIN users ON jobs.user_id = users.id ORDER BY jobs.created_at DESC");
?>

<div class="md:ml-1/5 p-6">
    <h2 class="text-2xl font-bold mb-4">Job Posts</h2>
    <table class="min-w-full bg-white shadow-md rounded">
        <thead>
            <tr class="bg-gray-200">
                <th class="p-2">ID</th>
                <th class="p-2">Posted By</th>
                <th class="p-2">Title</th>
                <th class="p-2">Description</th>
                <th class="p-2">Date</th>
                <th class="p-2">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr class="border-b">
                    <td class="p-2"><?php echo $row['id']; ?></td>
                    <td class="p-2"><?php echo $row['name']; ?></td>
                    <td class="p-2"><?php echo $row['job_title']; ?></td>
                    <td class="p-2"><?php echo substr($row['job_description'], 0, 50) . '...'; ?></td>
                    <td class="p-2"><?php echo $row['created_at']; ?></td>
                    <td class="p-2">
                        <a href="delete_job.php?id=<?php echo $row['id']; ?>" class="bg-red-500 text-white px-3 py-1 rounded">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
