<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}
?>



<?php
include 'header.php';
include 'db.php';

// Fetch all user reports from the correct `user_reports` table
$result = $conn->query("SELECT user_reports.id, reporter.name AS reporter_name, 
                        reported.name AS reported_user, user_reports.report_reason, 
                        user_reports.created_at 
                        FROM user_reports 
                        JOIN users AS reporter ON user_reports.reporter_id = reporter.id 
                        JOIN users AS reported ON user_reports.reported_user_id = reported.id 
                        ORDER BY user_reports.created_at DESC");

                        // Show success/error messages
if (isset($_SESSION['success'])) {
    echo '<div class="p-4 mb-4 text-green-700 bg-green-200 rounded-lg text-center">'.$_SESSION['success'].'</div>';
    unset($_SESSION['success']);
} elseif (isset($_SESSION['error'])) {
    echo '<div class="p-4 mb-4 text-red-700 bg-red-200 rounded-lg text-center">'.$_SESSION['error'].'</div>';
    unset($_SESSION['error']);
}
?>

<div class="p-6 max-w-6xl mx-auto">
    <h2 class="text-3xl font-bold mb-6 text-center text-gray-700">🚨 User Reports</h2>

    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        <table class="min-w-full border border-gray-200">
            <thead class="bg-red-600 text-white">
                <tr>
                    <th class="p-3 text-left">ID</th>
                    <th class="p-3 text-left">Reporter</th>
                    <th class="p-3 text-left">Reported User</th>
                    <th class="p-3 text-left">Reason</th>
                    <th class="p-3 text-left">Date</th>
                    <th class="p-3 text-center">Action</th>
                </tr>
            </thead>
            <tbody class="text-gray-700">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr class="border-b hover:bg-gray-100 transition">
                        <td class="p-3"><?php echo $row['id']; ?></td>
                        <td class="p-3"><?php echo $row['reporter_name']; ?></td>
                        <td class="p-3"><?php echo $row['reported_user']; ?></td>
                        <td class="p-3"><?php echo substr($row['report_reason'], 0, 50) . '...'; ?></td>
                        <td class="p-3"><?php echo date('F d, Y', strtotime($row['created_at'])); ?></td>
                        <td class="p-3 text-center">
                            <a href="delete_report.php?id=<?php echo $row['id']; ?>" 
                               class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition">
                               ❌ Delete
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>


