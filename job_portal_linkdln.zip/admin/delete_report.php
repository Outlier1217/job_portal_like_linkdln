<?php
session_start();
include 'db.php';

// Check if an ID is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid request.");
}

$report_id = intval($_GET['id']); // Convert ID to an integer for security

// Prepare and execute the delete query
$stmt = $conn->prepare("DELETE FROM user_reports WHERE id = ?");
$stmt->bind_param("i", $report_id);

if ($stmt->execute()) {
    // Redirect back with success message
    $_SESSION['success'] = "Report deleted successfully.";
} else {
    // Redirect back with error message
    $_SESSION['error'] = "Error deleting report.";
}

$stmt->close();
$conn->close();

// Redirect to reports.php
header("Location: reports.php");
exit();
?>
