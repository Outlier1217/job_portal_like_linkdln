<?php
include 'db.php';

if (isset($_GET['id'])) {
    $tieup_id = intval($_GET['id']);

    // Delete the tie-up request
    if ($conn->query("DELETE FROM tie_up_requests WHERE id = $tieup_id")) {
        header("Location: tieups.php?message=Tie-Up request deleted successfully");
    } else {
        echo "Error deleting tie-up request: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
