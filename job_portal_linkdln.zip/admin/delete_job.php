<?php
include 'db.php';

if (isset($_GET['id'])) {
    $job_id = intval($_GET['id']);

    // Delete related comments first (if comments are allowed on jobs)
    $conn->query("DELETE FROM comments WHERE post_id = $job_id");

    // Now delete the job post
    if ($conn->query("DELETE FROM jobs WHERE id = $job_id")) {
        header("Location: jobs.php?message=Job deleted successfully");
    } else {
        echo "Error deleting job: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
