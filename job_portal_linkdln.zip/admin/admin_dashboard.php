<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="max-w-4xl mx-auto mt-10 p-6 bg-white shadow-lg rounded-lg">
        <h2 class="text-2xl font-bold text-center">Admin Dashboard</h2>
        <div class="mt-6 text-center">
            <a href="dashboard.php" class="block bg-blue-500 text-white px-4 py-2 rounded mb-2">Manage Users</a>
            <a href="comments.php" class="block bg-blue-500 text-white px-4 py-2 rounded mb-2">Manage Comments</a>
            <a href="jobs.php" class="block bg-blue-500 text-white px-4 py-2 rounded mb-2">Manage Jobs</a>
            <a href="messages.php" class="block bg-blue-500 text-white px-4 py-2 rounded mb-2">Manage Messages</a>
            <a href="reports.php" class="block bg-blue-500 text-white px-4 py-2 rounded mb-2">Manage Reports</a>
            <a href="tieups.php" class="block bg-blue-500 text-white px-4 py-2 rounded mb-2">Manage Tie-Ups</a>
            <a href="admin_logout.php" class="block bg-red-500 text-white px-4 py-2 rounded">Logout</a>
        </div>
    </div>
</body>
</html>
