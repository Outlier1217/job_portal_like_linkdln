<div class="md:w-1/5 bg-white shadow-md h-full fixed p-4">
    <h3 class="text-lg font-bold mb-4">Navigation</h3>
    <ul class="space-y-2">
        <li><a href="dashboard.php" class="block bg-blue-500 text-white px-4 py-2 rounded">Users</a></li>
        <li><a href="comments.php" class="block bg-blue-500 text-white px-4 py-2 rounded">Comments</a></li>
        <li><a href="jobs.php" class="block bg-blue-500 text-white px-4 py-2 rounded">Jobs</a></li>
        <li><a href="messages.php" class="block bg-blue-500 text-white px-4 py-2 rounded">Messages</a></li>
        <li><a href="reports.php" class="block bg-blue-500 text-white px-4 py-2 rounded">Reports</a></li>
        <li><a href="tieups.php" class="block bg-blue-500 text-white px-4 py-2 rounded">Tie-Ups</a></li>
    </ul>
</div>
