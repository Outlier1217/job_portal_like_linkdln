<?php
session_start();
include 'header.php';

include 'db.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../auth/admin_login.php");
    exit();
}

// Fetch all users' education & experience
$query = "SELECT ee.id, u.name AS user_name, ee.type, ee.institution, ee.degree_or_role, 
                 ee.job_role, ee.current_post_role, ee.start_date, ee.end_date, ee.description
          FROM education_experience ee
          JOIN users u ON ee.user_id = u.id
          ORDER BY ee.start_date DESC";
$result = mysqli_query($conn, $query);
?>

<div class="min-h-screen bg-gray-100 py-10 px-4 md:px-10">
    <div class="max-w-6xl mx-auto bg-white shadow-lg rounded-lg p-8">
        <h2 class="text-2xl font-bold text-gray-800 text-center">📜 User Education & Experience</h2>
        <p class="text-gray-600 text-center mt-2">Below is the list of all users' education and work experience.</p>

        <!-- Display User Education & Experience -->
        <?php if (mysqli_num_rows($result) > 0): ?>
            <table class="w-full mt-6 bg-white shadow-lg rounded-lg">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="p-2">User Name</th>
                        <th class="p-2">Type</th>
                        <th class="p-2">Institution</th>
                        <th class="p-2">Degree/Role</th>
                        <th class="p-2">Job Role</th>
                        <th class="p-2">Current Role</th>
                        <th class="p-2">Start - End</th>
                        <th class="p-2">Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr class="border-b">
                            <td class="p-2"><?php echo htmlspecialchars($row['user_name']); ?></td>
                            <td class="p-2"><?php echo ucfirst($row['type']); ?></td>
                            <td class="p-2"><?php echo htmlspecialchars($row['institution']); ?></td>
                            <td class="p-2"><?php echo htmlspecialchars($row['degree_or_role']); ?></td>
                            <td class="p-2"><?php echo htmlspecialchars($row['job_role']); ?></td>
                            <td class="p-2"><?php echo htmlspecialchars($row['current_post_role']); ?></td>
                            <td class="p-2">
                                <?php echo date("M Y", strtotime($row['start_date'])) . " - " . 
                                    ($row['end_date'] ? date("M Y", strtotime($row['end_date'])) : "Present"); ?>
                            </td>
                            <td class="p-2"><?php echo htmlspecialchars($row['description']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-gray-500 mt-4 text-center">No education or experience records found.</p>
        <?php endif; ?>
    </div>
</div>


