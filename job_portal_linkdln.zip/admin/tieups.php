
<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}
?>




<?php
include 'header.php';

include 'db.php';

$result = $conn->query("SELECT tie_up_requests.id, sender.name AS sender_name, receiver.name AS receiver_name, 
                        tie_up_requests.status, tie_up_requests.created_at 
                        FROM tie_up_requests 
                        JOIN users AS sender ON tie_up_requests.sender_id = sender.id 
                        JOIN users AS receiver ON tie_up_requests.receiver_id = receiver.id 
                        ORDER BY tie_up_requests.created_at DESC");
?>

<div class="md:ml-1/5 p-6">
    <h2 class="text-2xl font-bold mb-4">Tie-Up Requests</h2>
    <table class="min-w-full bg-white shadow-md rounded">
        <thead>
            <tr class="bg-gray-200">
                <th class="p-2">ID</th>
                <th class="p-2">Sender</th>
                <th class="p-2">Receiver</th>
                <th class="p-2">Status</th>
                <th class="p-2">Date</th>
                <th class="p-2">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr class="border-b">
                    <td class="p-2"><?php echo $row['id']; ?></td>
                    <td class="p-2"><?php echo $row['sender_name']; ?></td>
                    <td class="p-2"><?php echo $row['receiver_name']; ?></td>
                    <td class="p-2"><?php echo ucfirst($row['status']); ?></td>
                    <td class="p-2"><?php echo $row['created_at']; ?></td>
                    <td class="p-2">
                        <a href="delete_tieup.php?id=<?php echo $row['id']; ?>" class="bg-red-500 text-white px-3 py-1 rounded">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
