<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Change this if needed
define('DB_PASS', ''); // Change this if you set a password
define('DB_NAME', 'job_portal');

// Start session
session_start();

// Connect to the database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Base URL for the project
define('BASE_URL', 'http://localhost/joballoc/');
?>