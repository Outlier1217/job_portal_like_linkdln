<?php include '../includes/header.php'; ?>

<div class="max-w-md mx-auto mt-10 bg-white p-6 rounded shadow">
    <h2 class="text-2xl font-bold mb-4">Forgot Password</h2>

    <!-- Display success or error messages -->
    <?php if (isset($_SESSION['success'])): ?>
        <p class="bg-green-200 text-green-800 p-2 rounded"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></p>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <p class="bg-red-200 text-red-800 p-2 rounded"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
    <?php endif; ?>

    <form action="process_forgot_password.php" method="POST">
        <input type="email" name="email" placeholder="Enter your email" required class="w-full p-2 border rounded mb-3">
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded w-full">Send Reset Link</button>
    </form>

    <!-- Back to Login -->
    <p class="text-center text-gray-600 mt-4">
        Remember your password? 
        <a href="login.php" class="text-blue-500 font-semibold hover:underline">Login here</a>.
    </p>
</div>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3871561533900538"
     crossorigin="anonymous"></script>

<?php include '../includes/footer.php'; ?>
