<?php
session_start();
include '../includes/db.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encrypt password

    // Handle profile picture upload
    $profile_picture = "default.png"; // Default profile picture

    if (!empty($_FILES["profile_picture"]["name"])) {
        $target_dir = "../assets/images/";
        $imageFileType = strtolower(pathinfo($_FILES["profile_picture"]["name"], PATHINFO_EXTENSION));
        $profile_picture = uniqid() . "." . $imageFileType; // Generate unique name
        $target_file = $target_dir . $profile_picture;

        // Check file size (max 2MB)
        if ($_FILES["profile_picture"]["size"] > 2000000) {
            $_SESSION['error'] = "File size must be less than 2MB.";
            header("Location: signup.php");
            exit();
        }

        // Allow only certain file formats
        if (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
            $_SESSION['error'] = "Only JPG, JPEG, PNG & GIF files are allowed.";
            header("Location: signup.php");
            exit();
        }

        // Move uploaded file to the assets/images directory
        if (!move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
            $_SESSION['error'] = "Error uploading file.";
            header("Location: signup.php");
            exit();
        }
    }

    // Insert into database
    $query = "INSERT INTO users (name, email, password, profile_picture) VALUES ('$name', '$email', '$password', '$profile_picture')";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Signup successful! You can now log in.";
        header("Location: login.php");
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
        header("Location: signup.php");
    }
}
?>
