<?php
session_start();
include '../includes/db.php';
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    mysqli_query($conn, "UPDATE users SET is_online = 0 WHERE id = '$user_id'");
}
session_destroy();
header("Location: ../auth/login.php");
exit();
?>
