<?php
session_start();
include '../includes/db.php';

// Check if the request is a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Check if the email exists in the database
    $query = "SELECT id FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $user_id = $user['id'];

        // Generate a unique reset token
        $token = bin2hex(random_bytes(32));
        $expires_at = date("Y-m-d H:i:s", strtotime("+1 hour")); // Token valid for 1 hour

        // Store the reset token in the database
        $query = "UPDATE users SET password_reset_token='$token', token_expires_at='$expires_at' WHERE id='$user_id'";
        mysqli_query($conn, $query);

        // Send the reset email
        $reset_link = "https://joballoc.in/auth/reset_password.php?token=$token";
        $subject = "Password Reset Request";
        $message = "Click the link below to reset your password:\n\n$reset_link\n\nThis link will expire in 1 hour.";
        $headers = "From: support@joballoc.in";

        mail($email, $subject, $message, $headers);

        $_SESSION['success'] = "A reset link has been sent to your email.";
    } else {
        $_SESSION['error'] = "No account found with that email.";
    }

    header("Location: forgot_password.php");
    exit();
}
?>
