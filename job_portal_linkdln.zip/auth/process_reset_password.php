<?php
session_start();
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: reset_password.php?token=" . $_POST['token']);
        exit();
    }

    // Hash the new password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update password and remove token
    $query = "UPDATE users SET password='$hashed_password', password_reset_token=NULL, token_expires_at=NULL WHERE id='$user_id'";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Password successfully reset. You can now log in.";
        header("Location: login.php");
    } else {
        $_SESSION['error'] = "Something went wrong. Please try again.";
        header("Location: reset_password.php?token=" . $_POST['token']);
    }
}
?>
