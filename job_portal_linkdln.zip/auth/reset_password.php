<?php
session_start();
include '../includes/db.php';

if (!isset($_GET['token'])) {
    die("Invalid or expired reset link.");
}

$token = $_GET['token'];

// Check if the token is valid
$query = "SELECT id FROM users WHERE password_reset_token='$token' AND token_expires_at > NOW()";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    die("Invalid or expired reset link.");
}

$user = mysqli_fetch_assoc($result);
$user_id = $user['id'];

?>

<?php include '../includes/header.php'; ?>

<div class="max-w-md mx-auto mt-10 bg-white p-6 rounded shadow">
    <h2 class="text-2xl font-bold mb-4">Reset Password</h2>

    <form action="process_reset_password.php" method="POST">
        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
        <input type="password" name="new_password" placeholder="New Password" required class="w-full p-2 border rounded mb-3">
        <input type="password" name="confirm_password" placeholder="Confirm Password" required class="w-full p-2 border rounded mb-3">
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded w-full">Reset Password</button>
    </form>

    <!-- Back to Login -->
    <p class="text-center text-gray-600 mt-4">
        Remember your password? 
        <a href="login.php" class="text-blue-500 font-semibold hover:underline">Login here</a>.
    </p>
</div>

<?php include '../includes/footer.php'; ?>
